import { createSlice } from '@reduxjs/toolkit'

const uiSlice = createSlice({
  name: 'ui',
  initialState: {
    mobileMenuOpen: false,
    searchOpen: false,
    cartDrawerOpen: false,
    filterDrawerOpen: false,
    notifications: [],
  },
  reducers: {
    toggleMobileMenu: (state) => {
      state.mobileMenuOpen = !state.mobileMenuOpen
    },
    toggleSearch: (state) => {
      state.searchOpen = !state.searchOpen
    },
    toggleCartDrawer: (state) => {
      state.cartDrawerOpen = !state.cartDrawerOpen
    },
    toggleFilterDrawer: (state) => {
      state.filterDrawerOpen = !state.filterDrawerOpen
    },
    addNotification: (state, action) => {
      state.notifications.push({
        id: Date.now(),
        ...action.payload,
      })
    },
    removeNotification: (state, action) => {
      state.notifications = state.notifications.filter(
        notification => notification.id !== action.payload
      )
    },
    clearAllNotifications: (state) => {
      state.notifications = []
    },
    closeMobileMenu: (state) => {
      state.mobileMenuOpen = false
    },
  },
})

export const { 
  toggleMobileMenu, 
  toggleSearch, 
  toggleCartDrawer, 
  toggleFilterDrawer,
  addNotification,
  removeNotification,
  clearAllNotifications,
  closeMobileMenu
} = uiSlice.actions

export default uiSlice.reducer