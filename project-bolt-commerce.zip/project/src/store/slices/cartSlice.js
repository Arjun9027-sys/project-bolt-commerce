import { createSlice } from '@reduxjs/toolkit'

const initialState = {
  items: [],
  totalQuantity: 0,
  totalAmount: 0,
}

const calculateTotals = (items) => {
  const totalQuantity = items.reduce((total, item) => total + item.quantity, 0)
  const totalAmount = items.reduce(
    (total, item) => total + item.price * item.quantity,
    0
  )
  return { totalQuantity, totalAmount }
}

const cartSlice = createSlice({
  name: 'cart',
  initialState,
  reducers: {
    addToCart: (state, action) => {
      const newItem = action.payload
      const existingItem = state.items.find(item => item.id === newItem.id)
      
      if (existingItem) {
        existingItem.quantity += newItem.quantity || 1
      } else {
        state.items.push({
          ...newItem,
          quantity: newItem.quantity || 1,
        })
      }
      
      const { totalQuantity, totalAmount } = calculateTotals(state.items)
      state.totalQuantity = totalQuantity
      state.totalAmount = totalAmount
    },
    
    removeFromCart: (state, action) => {
      const id = action.payload
      state.items = state.items.filter(item => item.id !== id)
      
      const { totalQuantity, totalAmount } = calculateTotals(state.items)
      state.totalQuantity = totalQuantity
      state.totalAmount = totalAmount
    },
    
    updateQuantity: (state, action) => {
      const { id, quantity } = action.payload
      const item = state.items.find(item => item.id === id)
      
      if (item) {
        item.quantity = Math.max(1, quantity)
      }
      
      const { totalQuantity, totalAmount } = calculateTotals(state.items)
      state.totalQuantity = totalQuantity
      state.totalAmount = totalAmount
    },
    
    clearCart: (state) => {
      state.items = []
      state.totalQuantity = 0
      state.totalAmount = 0
    },
  },
})

export const { addToCart, removeFromCart, updateQuantity, clearCart } = cartSlice.actions
export default cartSlice.reducer