import { useState } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { Link, useNavigate } from 'react-router-dom'
import { FiTrash2, FiPlus, FiMinus, FiArrowLeft } from 'react-icons/fi'

import { removeFromCart, updateQuantity, clearCart } from '../store/slices/cartSlice'

const CartPage = () => {
  const dispatch = useDispatch()
  const navigate = useNavigate()
  const { items, totalQuantity, totalAmount } = useSelector(state => state.cart)
  const [couponCode, setCouponCode] = useState('')
  const [couponError, setCouponError] = useState('')
  
  // Handle quantity update
  const handleUpdateQuantity = (id, quantity) => {
    dispatch(updateQuantity({ id, quantity }))
  }
  
  // Handle remove item
  const handleRemoveItem = (id) => {
    dispatch(removeFromCart(id))
  }
  
  // Handle clear cart
  const handleClearCart = () => {
    if (window.confirm('Are you sure you want to clear your cart?')) {
      dispatch(clearCart())
    }
  }
  
  // Handle apply coupon
  const handleApplyCoupon = (e) => {
    e.preventDefault()
    
    if (!couponCode.trim()) {
      setCouponError('Please enter a coupon code')
      return
    }
    
    // Mock coupon validation
    if (couponCode.toLowerCase() === 'discount10') {
      setCouponError('')
      alert('Coupon applied successfully! (This is a mock implementation)')
    } else {
      setCouponError('Invalid or expired coupon code')
    }
  }
  
  // Calculate shipping (free for orders over $50)
  const shipping = totalAmount > 50 ? 0 : 9.99
  
  // Calculate tax (mock 8.5%)
  const tax = totalAmount * 0.085
  
  // Calculate order total
  const orderTotal = totalAmount + shipping + tax
  
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-8">Shopping Cart</h1>
      
      {items.length === 0 ? (
        <div className="bg-white rounded-lg shadow-sm p-8 text-center">
          <div className="w-20 h-20 mx-auto mb-4 bg-neutral-100 rounded-full flex items-center justify-center">
            <svg className="w-10 h-10 text-neutral-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z" />
            </svg>
          </div>
          <h2 className="text-2xl font-bold mb-2">Your cart is empty</h2>
          <p className="text-neutral-600 mb-6">
            Looks like you haven't added any products to your cart yet.
          </p>
          <Link to="/products" className="btn btn-primary">
            Start Shopping
          </Link>
        </div>
      ) : (
        <div className="flex flex-col lg:flex-row gap-8">
          {/* Cart items */}
          <div className="lg:w-2/3">
            <div className="bg-white rounded-lg shadow-sm overflow-hidden mb-4">
              <table className="min-w-full divide-y divide-neutral-200">
                <thead className="bg-neutral-50">
                  <tr>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">
                      Product
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">
                      Price
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">
                      Quantity
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">
                      Total
                    </th>
                    <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-neutral-500 uppercase tracking-wider">
                      <span className="sr-only">Remove</span>
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-neutral-200">
                  {items.map((item) => (
                    <tr key={item.id}>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="flex items-center">
                          <div className="h-16 w-16 flex-shrink-0">
                            <img 
                              className="h-16 w-16 object-cover rounded-md" 
                              src={item.image} 
                              alt={item.name} 
                            />
                          </div>
                          <div className="ml-4">
                            <Link 
                              to={`/products/${item.id}`} 
                              className="text-neutral-900 font-medium hover:text-primary-600"
                            >
                              {item.name}
                            </Link>
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-neutral-900">${item.price.toFixed(2)}</div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="flex items-center border rounded w-32">
                          <button
                            type="button"
                            className="p-2 text-neutral-600 hover:text-primary-600"
                            onClick={() => handleUpdateQuantity(item.id, item.quantity - 1)}
                            disabled={item.quantity <= 1}
                          >
                            <FiMinus size={16} />
                          </button>
                          <span className="flex-1 text-center py-1">{item.quantity}</span>
                          <button
                            type="button"
                            className="p-2 text-neutral-600 hover:text-primary-600"
                            onClick={() => handleUpdateQuantity(item.id, item.quantity + 1)}
                          >
                            <FiPlus size={16} />
                          </button>
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-neutral-900 font-medium">
                          ${(item.price * item.quantity).toFixed(2)}
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-right">
                        <button
                          type="button"
                          className="text-error-500 hover:text-error-700"
                          onClick={() => handleRemoveItem(item.id)}
                        >
                          <FiTrash2 size={18} />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            
            {/* Actions */}
            <div className="flex justify-between items-center">
              <Link 
                to="/products" 
                className="flex items-center gap-2 text-primary-600 hover:text-primary-700"
              >
                <FiArrowLeft />
                Continue Shopping
              </Link>
              
              <button
                type="button"
                onClick={handleClearCart}
                className="text-neutral-600 hover:text-error-500"
              >
                Clear Cart
              </button>
            </div>
          </div>
          
          {/* Order summary */}
          <div className="lg:w-1/3">
            <div className="bg-white rounded-lg shadow-sm p-6">
              <h2 className="text-xl font-bold mb-6">Order Summary</h2>
              
              <div className="space-y-4 mb-6">
                <div className="flex justify-between">
                  <span className="text-neutral-600">Subtotal ({totalQuantity} items)</span>
                  <span className="font-medium">${totalAmount.toFixed(2)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-neutral-600">Shipping</span>
                  <span className="font-medium">
                    {shipping === 0 ? 'Free' : `$${shipping.toFixed(2)}`}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-neutral-600">Tax (8.5%)</span>
                  <span className="font-medium">${tax.toFixed(2)}</span>
                </div>
                <div className="border-t pt-4 flex justify-between">
                  <span className="font-bold">Order Total</span>
                  <span className="font-bold text-xl">${orderTotal.toFixed(2)}</span>
                </div>
              </div>
              
              {/* Coupon code */}
              <form onSubmit={handleApplyCoupon} className="mb-6">
                <label htmlFor="coupon" className="block text-sm font-medium text-neutral-700 mb-2">
                  Apply Coupon Code
                </label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    id="coupon"
                    name="coupon"
                    value={couponCode}
                    onChange={(e) => setCouponCode(e.target.value)}
                    className="flex-1 p-2 border border-neutral-300 rounded-md focus:border-primary-500 focus:ring-2 focus:ring-primary-500 focus:outline-none"
                    placeholder="Enter coupon code"
                  />
                  <button type="submit" className="btn btn-outline">
                    Apply
                  </button>
                </div>
                {couponError && <p className="mt-1 text-sm text-error-500">{couponError}</p>}
              </form>
              
              {/* Checkout button */}
              <button
                onClick={() => navigate('/checkout')}
                className="w-full btn btn-primary py-3"
              >
                Proceed to Checkout
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

export default CartPage