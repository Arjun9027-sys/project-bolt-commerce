import { useEffect, useState } from 'react'
import { useParams, Link } from 'react-router-dom'
import { useDispatch, useSelector } from 'react-redux'
import { FiStar, FiMinus, FiPlus, FiHeart, FiShoppingCart, FiShare2, FiChevronRight } from 'react-icons/fi'

import { fetchProductById, clearCurrentProduct } from '../store/slices/productSlice'
import { addToCart } from '../store/slices/cartSlice'
import { addNotification } from '../store/slices/uiSlice'
import Loading from '../components/common/Loading'
import ProductCard from '../components/products/ProductCard'

const ProductDetailPage = () => {
  const { productId } = useParams()
  const dispatch = useDispatch()
  const { currentProduct, items, loading } = useSelector(state => state.products)
  const [quantity, setQuantity] = useState(1)
  const [activeImage, setActiveImage] = useState(0)
  const [activeTab, setActiveTab] = useState('description')
  
  useEffect(() => {
    // Fetch the product
    dispatch(fetchProductById(productId))
    
    // Cleanup when leaving the page
    return () => {
      dispatch(clearCurrentProduct())
    }
  }, [dispatch, productId])
  
  useEffect(() => {
    // Reset quantity and active image when product changes
    setQuantity(1)
    setActiveImage(0)
  }, [currentProduct])
  
  // Handle quantity change
  const handleQuantityChange = (value) => {
    setQuantity(Math.max(1, Math.min(value, currentProduct?.countInStock || 10)))
  }
  
  // Handle add to cart
  const handleAddToCart = () => {
    if (!currentProduct) return
    
    dispatch(addToCart({
      id: currentProduct.id,
      name: currentProduct.name,
      price: currentProduct.price,
      image: currentProduct.image,
      quantity: quantity,
    }))
    
    dispatch(addNotification({
      type: 'success',
      message: `${currentProduct.name} added to cart!`,
    }))
  }
  
  // Get related products (same category)
  const getRelatedProducts = () => {
    if (!currentProduct || !items.length) return []
    
    return items
      .filter(item => 
        item.category === currentProduct.category && 
        item.id !== currentProduct.id
      )
      .slice(0, 4)
  }
  
  if (loading || !currentProduct) {
    return (
      <div className="container mx-auto px-4 py-16">
        <Loading />
      </div>
    )
  }
  
  const relatedProducts = getRelatedProducts()
  
  return (
    <div className="container mx-auto px-4 py-8">
      {/* Breadcrumbs */}
      <div className="flex items-center text-sm mb-8">
        <Link to="/" className="text-neutral-500 hover:text-primary-600">Home</Link>
        <FiChevronRight className="mx-2 text-neutral-400" />
        <Link to="/products" className="text-neutral-500 hover:text-primary-600">Products</Link>
        <FiChevronRight className="mx-2 text-neutral-400" />
        <Link 
          to={`/products?category=${currentProduct.category}`} 
          className="text-neutral-500 hover:text-primary-600"
        >
          {currentProduct.category}
        </Link>
        <FiChevronRight className="mx-2 text-neutral-400" />
        <span className="text-neutral-800 font-medium line-clamp-1">{currentProduct.name}</span>
      </div>
      
      {/* Product details */}
      <div className="flex flex-col lg:flex-row gap-8 mb-16">
        {/* Product images */}
        <div className="lg:w-1/2">
          <div className="bg-white rounded-lg overflow-hidden mb-4">
            <img
              src={currentProduct.image}
              alt={currentProduct.name}
              className="w-full h-[400px] object-contain"
            />
          </div>
          
          {/* Thumbnail gallery (placeholder for multiple images) */}
          <div className="grid grid-cols-4 gap-2">
            {[...Array(4)].map((_, index) => (
              <button
                key={index}
                onClick={() => setActiveImage(index)}
                className={`border rounded-md overflow-hidden ${
                  activeImage === index ? 'border-primary-500' : 'border-neutral-200'
                }`}
              >
                <img
                  src={currentProduct.image}
                  alt={`${currentProduct.name} view ${index + 1}`}
                  className="w-full h-20 object-cover"
                />
              </button>
            ))}
          </div>
        </div>
        
        {/* Product info */}
        <div className="lg:w-1/2">
          <div className="bg-white rounded-lg shadow-sm p-6">
            {/* Category and name */}
            <p className="text-sm text-neutral-500 mb-2">{currentProduct.category}</p>
            <h1 className="text-3xl font-bold text-neutral-900 mb-2">{currentProduct.name}</h1>
            
            {/* Rating */}
            <div className="flex items-center gap-1 mb-4">
              <FiStar className="text-warning-500 fill-current" />
              <span className="text-sm font-medium">
                {currentProduct.rating} ({currentProduct.reviews.length} reviews)
              </span>
            </div>
            
            {/* Price and stock */}
            <div className="mb-6">
              <p className="text-3xl font-bold text-neutral-900">
                ${currentProduct.price.toFixed(2)}
              </p>
              <div className="flex items-center mt-2">
                <span className={`text-sm px-2 py-1 rounded ${
                  currentProduct.countInStock > 0 
                    ? 'bg-success-500 bg-opacity-10 text-success-500' 
                    : 'bg-error-500 bg-opacity-10 text-error-500'
                }`}>
                  {currentProduct.countInStock > 0 
                    ? `In Stock (${currentProduct.countInStock} available)` 
                    : 'Out of Stock'}
                </span>
              </div>
            </div>
            
            {/* Short description */}
            <p className="text-neutral-700 mb-6">{currentProduct.description}</p>
            
            {/* Quantity selector */}
            <div className="mb-6">
              <label className="block text-neutral-800 font-medium mb-2">Quantity</label>
              <div className="flex items-center">
                <button
                  onClick={() => handleQuantityChange(quantity - 1)}
                  className="p-2 border border-neutral-300 rounded-l-md text-neutral-600 hover:bg-neutral-100"
                  disabled={quantity <= 1}
                >
                  <FiMinus size={16} />
                </button>
                <input
                  type="number"
                  value={quantity}
                  onChange={(e) => handleQuantityChange(parseInt(e.target.value) || 1)}
                  className="w-16 p-2 text-center border-y border-neutral-300 focus:outline-none"
                  min="1"
                  max={currentProduct.countInStock}
                />
                <button
                  onClick={() => handleQuantityChange(quantity + 1)}
                  className="p-2 border border-neutral-300 rounded-r-md text-neutral-600 hover:bg-neutral-100"
                  disabled={quantity >= currentProduct.countInStock}
                >
                  <FiPlus size={16} />
                </button>
              </div>
            </div>
            
            {/* Action buttons */}
            <div className="flex flex-col sm:flex-row gap-4 mb-6">
              <button 
                onClick={handleAddToCart}
                className="flex-1 btn btn-primary py-3 flex items-center justify-center gap-2"
                disabled={currentProduct.countInStock === 0}
              >
                <FiShoppingCart size={18} />
                Add to Cart
              </button>
              <button className="sm:w-12 h-12 flex items-center justify-center border border-neutral-300 rounded-md text-neutral-600 hover:text-primary-600 hover:border-primary-600 transition-colors">
                <FiHeart size={20} />
              </button>
              <button className="sm:w-12 h-12 flex items-center justify-center border border-neutral-300 rounded-md text-neutral-600 hover:text-primary-600 hover:border-primary-600 transition-colors">
                <FiShare2 size={20} />
              </button>
            </div>
            
            {/* Additional info */}
            <div className="border-t border-neutral-200 pt-6">
              <div className="flex text-sm text-neutral-600">
                <div className="w-1/2">
                  <p className="mb-1">SKU: <span className="text-neutral-800">AP{currentProduct.id}1234</span></p>
                  <p>Category: <Link to={`/products?category=${currentProduct.category}`} className="text-primary-600 hover:underline">{currentProduct.category}</Link></p>
                </div>
                <div className="w-1/2">
                  <p className="mb-1">Free shipping</p>
                  <p>30-day returns</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      {/* Product tabs */}
      <div className="bg-white rounded-lg shadow-sm mb-16">
        {/* Tab headers */}
        <div className="flex border-b">
          <button
            onClick={() => setActiveTab('description')}
            className={`px-6 py-4 font-medium transition-colors ${
              activeTab === 'description' 
                ? 'text-primary-600 border-b-2 border-primary-600' 
                : 'text-neutral-600 hover:text-neutral-900'
            }`}
          >
            Description
          </button>
          <button
            onClick={() => setActiveTab('specifications')}
            className={`px-6 py-4 font-medium transition-colors ${
              activeTab === 'specifications' 
                ? 'text-primary-600 border-b-2 border-primary-600' 
                : 'text-neutral-600 hover:text-neutral-900'
            }`}
          >
            Specifications
          </button>
          <button
            onClick={() => setActiveTab('reviews')}
            className={`px-6 py-4 font-medium transition-colors ${
              activeTab === 'reviews' 
                ? 'text-primary-600 border-b-2 border-primary-600' 
                : 'text-neutral-600 hover:text-neutral-900'
            }`}
          >
            Reviews ({currentProduct.reviews.length})
          </button>
        </div>
        
        {/* Tab content */}
        <div className="p-6">
          {activeTab === 'description' && (
            <div>
              <h2 className="text-xl font-bold mb-4">Product Description</h2>
              <p className="text-neutral-700 mb-4">{currentProduct.description}</p>
              <p className="text-neutral-700 mb-4">
                Experience the latest technology with the {currentProduct.name}. Designed for performance and style, this {currentProduct.category.toLowerCase()} delivers exceptional quality and value.
              </p>
              <p className="text-neutral-700">
                From its sleek design to its powerful capabilities, the {currentProduct.name} is perfect for both personal and professional use. Enjoy premium features and reliability that you can count on day after day.
              </p>
            </div>
          )}
          
          {activeTab === 'specifications' && (
            <div>
              <h2 className="text-xl font-bold mb-4">Technical Specifications</h2>
              <div className="border rounded-lg overflow-hidden">
                <table className="w-full">
                  <tbody>
                    <tr className="border-b">
                      <td className="py-3 px-4 bg-neutral-50 font-medium">Model</td>
                      <td className="py-3 px-4">{currentProduct.name}</td>
                    </tr>
                    <tr className="border-b">
                      <td className="py-3 px-4 bg-neutral-50 font-medium">Category</td>
                      <td className="py-3 px-4">{currentProduct.category}</td>
                    </tr>
                    <tr className="border-b">
                      <td className="py-3 px-4 bg-neutral-50 font-medium">Rating</td>
                      <td className="py-3 px-4">{currentProduct.rating}/5</td>
                    </tr>
                    <tr className="border-b">
                      <td className="py-3 px-4 bg-neutral-50 font-medium">Availability</td>
                      <td className="py-3 px-4">{currentProduct.countInStock} in stock</td>
                    </tr>
                    <tr>
                      <td className="py-3 px-4 bg-neutral-50 font-medium">Warranty</td>
                      <td className="py-3 px-4">1 Year Limited Warranty</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          )}
          
          {activeTab === 'reviews' && (
            <div>
              <h2 className="text-xl font-bold mb-4">Customer Reviews</h2>
              
              {currentProduct.reviews.length === 0 ? (
                <p className="text-neutral-600">There are no reviews yet.</p>
              ) : (
                <div className="space-y-6">
                  {currentProduct.reviews.map(review => (
                    <div key={review.id} className="border-b pb-6">
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center gap-2">
                          <div className="h-10 w-10 bg-primary-100 rounded-full flex items-center justify-center text-primary-700 font-medium">
                            {review.username.charAt(0)}
                          </div>
                          <div>
                            <p className="font-medium">{review.username}</p>
                            <p className="text-xs text-neutral-500">{review.date}</p>
                          </div>
                        </div>
                        <div className="flex items-center">
                          <FiStar className="text-warning-500 fill-current" />
                          <span className="ml-1 font-medium">{review.rating}</span>
                        </div>
                      </div>
                      <p className="text-neutral-700">{review.comment}</p>
                    </div>
                  ))}
                </div>
              )}
              
              <div className="mt-8">
                <h3 className="font-bold mb-4">Write a Review</h3>
                <form className="space-y-4">
                  <div>
                    <label htmlFor="rating" className="block mb-1 font-medium">Rating</label>
                    <select 
                      id="rating" 
                      className="w-full p-2 border border-neutral-300 rounded-md focus:border-primary-500 focus:ring-2 focus:ring-primary-500 focus:outline-none"
                    >
                      <option value="5">5 - Excellent</option>
                      <option value="4">4 - Very Good</option>
                      <option value="3">3 - Good</option>
                      <option value="2">2 - Fair</option>
                      <option value="1">1 - Poor</option>
                    </select>
                  </div>
                  <div>
                    <label htmlFor="comment" className="block mb-1 font-medium">Review</label>
                    <textarea 
                      id="comment" 
                      rows="4" 
                      className="w-full p-2 border border-neutral-300 rounded-md focus:border-primary-500 focus:ring-2 focus:ring-primary-500 focus:outline-none"
                      placeholder="Share your experience with this product"
                    ></textarea>
                  </div>
                  <button type="submit" className="btn btn-primary">
                    Submit Review
                  </button>
                </form>
              </div>
            </div>
          )}
        </div>
      </div>
      
      {/* Related products */}
      {relatedProducts.length > 0 && (
        <div className="mb-16">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-2xl font-bold">Related Products</h2>
            <Link to={`/products?category=${currentProduct.category}`} className="text-primary-600 hover:text-primary-700 font-medium">
              View All
            </Link>
          </div>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {relatedProducts.map(product => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        </div>
      )}
    </div>
  )
}

export default ProductDetailPage