import { useEffect, useState } from 'react'
import { useParams, Link } from 'react-router-dom'
import { FiArrowLeft, FiPackage, FiTruck, FiCheck } from 'react-icons/fi'

import api from '../services/api'
import Loading from '../components/common/Loading'

const OrderDetailPage = () => {
  const { orderId } = useParams()
  const [order, setOrder] = useState(null)
  const [loading, setLoading] = useState(true)
  
  useEffect(() => {
    const fetchOrder = async () => {
      try {
        setLoading(true)
        const data = await api.orders.getOrderById(orderId)
        setOrder(data)
      } catch (error) {
        console.error('Error fetching order:', error)
      } finally {
        setLoading(false)
      }
    }
    
    fetchOrder()
  }, [orderId])
  
  if (loading) {
    return (
      <div className="container mx-auto px-4 py-8">
        <Loading />
      </div>
    )
  }
  
  if (!order) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="bg-white rounded-lg shadow-sm p-8 text-center">
          <h2 className="text-xl font-bold mb-2">Order not found</h2>
          <p className="text-neutral-600 mb-4">
            The order you're looking for doesn't exist or has been removed.
          </p>
          <Link to="/orders" className="btn btn-primary">
            View All Orders
          </Link>
        </div>
      </div>
    )
  }
  
  // Get status color
  const getStatusColor = (status) => {
    switch (status.toLowerCase()) {
      case 'delivered':
        return 'bg-success-500 bg-opacity-10 text-success-500'
      case 'shipped':
        return 'bg-primary-500 bg-opacity-10 text-primary-500'
      case 'processing':
        return 'bg-warning-500 bg-opacity-10 text-warning-500'
      case 'cancelled':
        return 'bg-error-500 bg-opacity-10 text-error-500'
      default:
        return 'bg-neutral-500 bg-opacity-10 text-neutral-500'
    }
  }
  
  return (
    <div className="container mx-auto px-4 py-8">
      {/* Header */}
      <div className="flex items-center justify-between mb-8">
        <div>
          <Link to="/orders" className="flex items-center text-primary-600 hover:text-primary-700 mb-2">
            <FiArrowLeft className="mr-2" />
            Back to Orders
          </Link>
          <h1 className="text-3xl font-bold">Order {order.id}</h1>
        </div>
        <span className={`px-3 py-1 rounded-full text-sm font-medium ${getStatusColor(order.status)}`}>
          {order.status}
        </span>
      </div>
      
      {/* Order tracking */}
      {order.tracking && (
        <div className="bg-white rounded-lg shadow-sm p-6 mb-8">
          <h2 className="text-xl font-bold mb-6">Order Tracking</h2>
          <div className="flex items-center justify-between mb-8">
            <div className="relative flex-1">
              <div className="h-1 bg-primary-500"></div>
              <div className="absolute -top-2 left-0 w-6 h-6 rounded-full bg-primary-500 text-white flex items-center justify-center">
                <FiPackage size={14} />
              </div>
              <p className="absolute top-6 left-0 text-sm font-medium">Order Placed</p>
              <p className="absolute top-10 left-0 text-xs text-neutral-500">{order.date}</p>
            </div>
            
            <div className="relative flex-1">
              <div className="h-1 bg-primary-500"></div>
              <div className="absolute -top-2 left-1/2 transform -translate-x-1/2 w-6 h-6 rounded-full bg-primary-500 text-white flex items-center justify-center">
                <FiTruck size={14} />
              </div>
              <p className="absolute top-6 left-1/2 transform -translate-x-1/2 text-sm font-medium">Shipped</p>
              <p className="absolute top-10 left-1/2 transform -translate-x-1/2 text-xs text-neutral-500">
                {order.tracking.estimated_delivery}
              </p>
            </div>
            
            <div className="relative flex-1">
              <div className={`h-1 ${order.status === 'Delivered' ? 'bg-primary-500' : 'bg-neutral-200'}`}></div>
              <div className={`absolute -top-2 right-0 w-6 h-6 rounded-full flex items-center justify-center ${
                order.status === 'Delivered' 
                  ? 'bg-primary-500 text-white'
                  : 'bg-neutral-200 text-neutral-400'
              }`}>
                <FiCheck size={14} />
              </div>
              <p className="absolute top-6 right-0 text-sm font-medium">Delivered</p>
              <p className="absolute top-10 right-0 text-xs text-neutral-500">
                {order.status === 'Delivered' ? order.tracking.estimated_delivery : 'Pending'}
              </p>
            </div>
          </div>
          
          <div className="border-t pt-6">
            <div className="flex justify-between text-sm">
              <div>
                <p className="font-medium">Tracking Number</p>
                <p className="text-neutral-600">{order.tracking.number}</p>
              </div>
              <div>
                <p className="font-medium">Carrier</p>
                <p className="text-neutral-600">{order.tracking.carrier}</p>
              </div>
              <div>
                <p className="font-medium">Estimated Delivery</p>
                <p className="text-neutral-600">{order.tracking.estimated_delivery}</p>
              </div>
            </div>
          </div>
        </div>
      )}
      
      {/* Order details */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Items */}
        <div className="lg:col-span-2">
          <div className="bg-white rounded-lg shadow-sm overflow-hidden">
            <div className="p-6 border-b">
              <h2 className="text-xl font-bold">Order Items</h2>
            </div>
            <div className="divide-y">
              {order.items.map((item) => (
                <div key={item.id} className="p-6 flex items-center">
                  <img
                    src={item.image}
                    alt={item.name}
                    className="w-20 h-20 object-cover rounded-lg"
                  />
                  <div className="ml-6 flex-1">
                    <Link 
                      to={`/products/${item.id}`}
                      className="text-lg font-medium hover:text-primary-600"
                    >
                      {item.name}
                    </Link>
                    <div className="flex justify-between items-center mt-2">
                      <p className="text-neutral-600">Quantity: {item.quantity}</p>
                      <p className="font-medium">${(item.price * item.quantity).toFixed(2)}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
        
        {/* Summary */}
        <div>
          <div className="bg-white rounded-lg shadow-sm p-6">
            <h2 className="text-xl font-bold mb-6">Order Summary</h2>
            
            {/* Payment info */}
            <div className="mb-6">
              <h3 className="font-medium mb-2">Payment Method</h3>
              <div className="bg-neutral-50 rounded p-3">
                <p className="font-medium">
                  {order.payment_method.type}
                  {order.payment_method.last_four && (
                    <span className="text-neutral-500">
                      {' '}ending in {order.payment_method.last_four}
                    </span>
                  )}
                </p>
              </div>
            </div>
            
            {/* Shipping address */}
            <div className="mb-6">
              <h3 className="font-medium mb-2">Shipping Address</h3>
              <div className="bg-neutral-50 rounded p-3">
                <p className="font-medium">{order.shipping_address.name}</p>
                <p>{order.shipping_address.street}</p>
                <p>
                  {order.shipping_address.city}, {order.shipping_address.state}{' '}
                  {order.shipping_address.zipCode}
                </p>
                <p>{order.shipping_address.country}</p>
              </div>
            </div>
            
            {/* Order total */}
            <div className="border-t pt-4">
              <div className="flex justify-between mb-2">
                <span className="text-neutral-600">Subtotal</span>
                <span>${order.total.toFixed(2)}</span>
              </div>
              <div className="flex justify-between mb-2">
                <span className="text-neutral-600">Shipping</span>
                <span>Free</span>
              </div>
              <div className="flex justify-between mb-4">
                <span className="text-neutral-600">Tax</span>
                <span>${(order.total * 0.085).toFixed(2)}</span>
              </div>
              <div className="flex justify-between font-bold text-lg">
                <span>Total</span>
                <span>${(order.total * 1.085).toFixed(2)}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default OrderDetailPage