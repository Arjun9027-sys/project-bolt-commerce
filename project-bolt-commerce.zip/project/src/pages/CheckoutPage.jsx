import { useState } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { useNavigate } from 'react-router-dom'
import { CardElement, useStripe, useElements } from '@stripe/react-stripe-js'
import { FiCreditCard, FiLock, FiCheckCircle } from 'react-icons/fi'

import { processPayment, createPaymentMethod } from '../services/stripe'
import { clearCart } from '../store/slices/cartSlice'
import api from '../services/api'
import { addNotification } from '../store/slices/uiSlice'

const CheckoutPage = () => {
  const dispatch = useDispatch()
  const navigate = useNavigate()
  const stripe = useStripe()
  const elements = useElements()
  const { items, totalAmount } = useSelector(state => state.cart)
  const { user } = useSelector(state => state.auth)
  
  // Checkout steps
  const STEPS = {
    SHIPPING: 'shipping',
    PAYMENT: 'payment',
    REVIEW: 'review',
    CONFIRMATION: 'confirmation',
  }
  
  // State
  const [step, setStep] = useState(STEPS.SHIPPING)
  const [loading, setLoading] = useState(false)
  const [paymentError, setPaymentError] = useState(null)
  const [shippingAddress, setShippingAddress] = useState({
    fullName: user?.name || '',
    addressLine1: user?.address?.street || '',
    addressLine2: '',
    city: user?.address?.city || '',
    state: user?.address?.state || '',
    zipCode: user?.address?.zipCode || '',
    country: user?.address?.country || 'USA',
    phone: user?.phone || '',
  })
  const [billingAddress, setBillingAddress] = useState({
    ...shippingAddress,
  })
  const [sameAsShipping, setSameAsShipping] = useState(true)
  const [paymentMethod, setPaymentMethod] = useState('credit-card')
  const [orderId, setOrderId] = useState(null)
  
  // Calculate shipping (free for orders over $50)
  const shipping = totalAmount > 50 ? 0 : 9.99
  
  // Calculate tax (mock 8.5%)
  const tax = totalAmount * 0.085
  
  // Calculate order total
  const orderTotal = totalAmount + shipping + tax
  
  // Handle shipping form change
  const handleShippingChange = (e) => {
    const { name, value } = e.target
    setShippingAddress(prev => ({ ...prev, [name]: value }))
    
    if (sameAsShipping) {
      setBillingAddress(prev => ({ ...prev, [name]: value }))
    }
  }
  
  // Handle billing form change
  const handleBillingChange = (e) => {
    const { name, value } = e.target
    setBillingAddress(prev => ({ ...prev, [name]: value }))
  }
  
  // Handle same as shipping change
  const handleSameAsShipping = (e) => {
    setSameAsShipping(e.target.checked)
    if (e.target.checked) {
      setBillingAddress({ ...shippingAddress })
    }
  }
  
  // Handle payment method change
  const handlePaymentMethodChange = (method) => {
    setPaymentMethod(method)
    setPaymentError(null)
  }
  
  // Handle continue to next step
  const handleContinue = () => {
    // Validate current step
    if (step === STEPS.SHIPPING) {
      // Simple validation
      const required = ['fullName', 'addressLine1', 'city', 'state', 'zipCode', 'country', 'phone']
      const missing = required.filter(field => !shippingAddress[field])
      
      if (missing.length > 0) {
        alert('Please fill in all required fields')
        return
      }
      
      setStep(STEPS.PAYMENT)
    } else if (step === STEPS.PAYMENT) {
      setStep(STEPS.REVIEW)
    }
  }
  
  // Handle go back
  const handleBack = () => {
    if (step === STEPS.PAYMENT) {
      setStep(STEPS.SHIPPING)
    } else if (step === STEPS.REVIEW) {
      setStep(STEPS.PAYMENT)
    }
  }
  
  // Handle place order
  const handlePlaceOrder = async () => {
    if (!stripe || !elements) {
      return
    }
    
    setLoading(true)
    setPaymentError(null)
    
    try {
      // Get card element
      const cardElement = elements.getElement(CardElement)
      
      // Create payment method
      const paymentMethodResult = await createPaymentMethod(cardElement, {
        name: billingAddress.fullName,
        address: {
          line1: billingAddress.addressLine1,
          line2: billingAddress.addressLine2,
          city: billingAddress.city,
          state: billingAddress.state,
          postal_code: billingAddress.zipCode,
          country: billingAddress.country,
        },
        phone: billingAddress.phone,
      })
      
      // Process payment
      await processPayment(paymentMethodResult.id, orderTotal * 100) // in cents
      
      // Place order
      const response = await api.orders.placeOrder({
        items,
        shippingAddress,
        billingAddress,
        paymentMethod,
        totalAmount: orderTotal,
      })
      
      // Set order ID for confirmation
      setOrderId(response.orderId)
      
      // Clear cart
      dispatch(clearCart())
      
      // Show success notification
      dispatch(addNotification({
        type: 'success',
        message: 'Order placed successfully!',
      }))
      
      // Move to confirmation step
      setStep(STEPS.CONFIRMATION)
    } catch (error) {
      console.error('Payment error:', error)
      setPaymentError(error.message)
    } finally {
      setLoading(false)
    }
  }
  
  // Render shipping form
  const renderShippingForm = () => (
    <>
      <h2 className="text-xl font-bold mb-6">Shipping Information</h2>
      
      <div className="space-y-4">
        <div>
          <label htmlFor="fullName" className="block text-sm font-medium text-neutral-700 mb-1">
            Full Name*
          </label>
          <input
            type="text"
            id="fullName"
            name="fullName"
            value={shippingAddress.fullName}
            onChange={handleShippingChange}
            className="w-full p-2 border border-neutral-300 rounded-md focus:border-primary-500 focus:ring-2 focus:ring-primary-500 focus:outline-none"
            required
          />
        </div>
        
        <div>
          <label htmlFor="addressLine1" className="block text-sm font-medium text-neutral-700 mb-1">
            Address Line 1*
          </label>
          <input
            type="text"
            id="addressLine1"
            name="addressLine1"
            value={shippingAddress.addressLine1}
            onChange={handleShippingChange}
            className="w-full p-2 border border-neutral-300 rounded-md focus:border-primary-500 focus:ring-2 focus:ring-primary-500 focus:outline-none"
            required
          />
        </div>
        
        <div>
          <label htmlFor="addressLine2" className="block text-sm font-medium text-neutral-700 mb-1">
            Address Line 2
          </label>
          <input
            type="text"
            id="addressLine2"
            name="addressLine2"
            value={shippingAddress.addressLine2}
            onChange={handleShippingChange}
            className="w-full p-2 border border-neutral-300 rounded-md focus:border-primary-500 focus:ring-2 focus:ring-primary-500 focus:outline-none"
          />
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label htmlFor="city" className="block text-sm font-medium text-neutral-700 mb-1">
              City*
            </label>
            <input
              type="text"
              id="city"
              name="city"
              value={shippingAddress.city}
              onChange={handleShippingChange}
              className="w-full p-2 border border-neutral-300 rounded-md focus:border-primary-500 focus:ring-2 focus:ring-primary-500 focus:outline-none"
              required
            />
          </div>
          
          <div>
            <label htmlFor="state" className="block text-sm font-medium text-neutral-700 mb-1">
              State/Province*
            </label>
            <input
              type="text"
              id="state"
              name="state"
              value={shippingAddress.state}
              onChange={handleShippingChange}
              className="w-full p-2 border border-neutral-300 rounded-md focus:border-primary-500 focus:ring-2 focus:ring-primary-500 focus:outline-none"
              required
            />
          </div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label htmlFor="zipCode" className="block text-sm font-medium text-neutral-700 mb-1">
              ZIP/Postal Code*
            </label>
            <input
              type="text"
              id="zipCode"
              name="zipCode"
              value={shippingAddress.zipCode}
              onChange={handleShippingChange}
              className="w-full p-2 border border-neutral-300 rounded-md focus:border-primary-500 focus:ring-2 focus:ring-primary-500 focus:outline-none"
              required
            />
          </div>
          
          <div>
            <label htmlFor="country" className="block text-sm font-medium text-neutral-700 mb-1">
              Country*
            </label>
            <select
              id="country"
              name="country"
              value={shippingAddress.country}
              onChange={handleShippingChange}
              className="w-full p-2 border border-neutral-300 rounded-md focus:border-primary-500 focus:ring-2 focus:ring-primary-500 focus:outline-none"
              required
            >
              <option value="USA">United States</option>
              <option value="CAN">Canada</option>
              <option value="GBR">United Kingdom</option>
              <option value="AUS">Australia</option>
            </select>
          </div>
        </div>
        
        <div>
          <label htmlFor="phone" className="block text-sm font-medium text-neutral-700 mb-1">
            Phone Number*
          </label>
          <input
            type="tel"
            id="phone"
            name="phone"
            value={shippingAddress.phone}
            onChange={handleShippingChange}
            className="w-full p-2 border border-neutral-300 rounded-md focus:border-primary-500 focus:ring-2 focus:ring-primary-500 focus:outline-none"
            required
          />
        </div>
      </div>
    </>
  )
  
  // Render payment form
  const renderPaymentForm = () => (
    <>
      <h2 className="text-xl font-bold mb-6">Payment Method</h2>
      
      <div className="space-y-4 mb-6">
        <div className="flex items-center">
          <input
            type="radio"
            id="credit-card"
            name="payment-method"
            value="credit-card"
            checked={paymentMethod === 'credit-card'}
            onChange={() => handlePaymentMethodChange('credit-card')}
            className="h-4 w-4 text-primary-600 focus:ring-primary-500"
          />
          <label htmlFor="credit-card" className="ml-2 flex items-center">
            <FiCreditCard className="mr-2" /> Credit or debit card
          </label>
        </div>
        
        <div className="flex items-center">
          <input
            type="radio"
            id="paypal"
            name="payment-method"
            value="paypal"
            checked={paymentMethod === 'paypal'}
            onChange={() => handlePaymentMethodChange('paypal')}
            className="h-4 w-4 text-primary-600 focus:ring-primary-500"
          />
          <label htmlFor="paypal" className="ml-2">PayPal</label>
        </div>
      </div>
      
      {paymentMethod === 'credit-card' && (
        <div className="mb-6">
          <div className="border border-neutral-300 rounded-md p-4 bg-white">
            <CardElement
              options={{
                style: {
                  base: {
                    fontSize: '16px',
                    color: '#424770',
                    '::placeholder': {
                      color: '#aab7c4',
                    },
                  },
                  invalid: {
                    color: '#9e2146',
                  },
                },
              }}
            />
          </div>
          {paymentError && (
            <p className="mt-2 text-sm text-error-500">{paymentError}</p>
          )}
          <div className="flex items-center mt-3 text-sm text-neutral-600">
            <FiLock className="mr-1" /> Your payment is secure and encrypted.
          </div>
        </div>
      )}
      
      <h2 className="text-xl font-bold mb-6 mt-8">Billing Address</h2>
      
      <div className="mb-4">
        <div className="flex items-center">
          <input
            type="checkbox"
            id="same-as-shipping"
            checked={sameAsShipping}
            onChange={handleSameAsShipping}
            className="h-4 w-4 text-primary-600 focus:ring-primary-500"
          />
          <label htmlFor="same-as-shipping" className="ml-2">
            Same as shipping address
          </label>
        </div>
      </div>
      
      {!sameAsShipping && (
        <div className="space-y-4">
          <div>
            <label htmlFor="billingFullName" className="block text-sm font-medium text-neutral-700 mb-1">
              Full Name*
            </label>
            <input
              type="text"
              id="billingFullName"
              name="fullName"
              value={billingAddress.fullName}
              onChange={handleBillingChange}
              className="w-full p-2 border border-neutral-300 rounded-md focus:border-primary-500 focus:ring-2 focus:ring-primary-500 focus:outline-none"
              required
            />
          </div>
          
          <div>
            <label htmlFor="billingAddressLine1" className="block text-sm font-medium text-neutral-700 mb-1">
              Address Line 1*
            </label>
            <input
              type="text"
              id="billingAddressLine1"
              name="addressLine1"
              value={billingAddress.addressLine1}
              onChange={handleBillingChange}
              className="w-full p-2 border border-neutral-300 rounded-md focus:border-primary-500 focus:ring-2 focus:ring-primary-500 focus:outline-none"
              required
            />
          </div>
          
          <div>
            <label htmlFor="billingAddressLine2" className="block text-sm font-medium text-neutral-700 mb-1">
              Address Line 2
            </label>
            <input
              type="text"
              id="billingAddressLine2"
              name="addressLine2"
              value={billingAddress.addressLine2}
              onChange={handleBillingChange}
              className="w-full p-2 border border-neutral-300 rounded-md focus:border-primary-500 focus:ring-2 focus:ring-primary-500 focus:outline-none"
            />
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label htmlFor="billingCity" className="block text-sm font-medium text-neutral-700 mb-1">
                City*
              </label>
              <input
                type="text"
                id="billingCity"
                name="city"
                value={billingAddress.city}
                onChange={handleBillingChange}
                className="w-full p-2 border border-neutral-300 rounded-md focus:border-primary-500 focus:ring-2 focus:ring-primary-500 focus:outline-none"
                required
              />
            </div>
            
            <div>
              <label htmlFor="billingState" className="block text-sm font-medium text-neutral-700 mb-1">
                State/Province*
              </label>
              <input
                type="text"
                id="billingState"
                name="state"
                value={billingAddress.state}
                onChange={handleBillingChange}
                className="w-full p-2 border border-neutral-300 rounded-md focus:border-primary-500 focus:ring-2 focus:ring-primary-500 focus:outline-none"
                required
              />
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label htmlFor="billingZipCode" className="block text-sm font-medium text-neutral-700 mb-1">
                ZIP/Postal Code*
              </label>
              <input
                type="text"
                id="billingZipCode"
                name="zipCode"
                value={billingAddress.zipCode}
                onChange={handleBillingChange}
                className="w-full p-2 border border-neutral-300 rounded-md focus:border-primary-500 focus:ring-2 focus:ring-primary-500 focus:outline-none"
                required
              />
            </div>
            
            <div>
              <label htmlFor="billingCountry" className="block text-sm font-medium text-neutral-700 mb-1">
                Country*
              </label>
              <select
                id="billingCountry"
                name="country"
                value={billingAddress.country}
                onChange={handleBillingChange}
                className="w-full p-2 border border-neutral-300 rounded-md focus:border-primary-500 focus:ring-2 focus:ring-primary-500 focus:outline-none"
                required
              >
                <option value="USA">United States</option>
                <option value="CAN">Canada</option>
                <option value="GBR">United Kingdom</option>
                <option value="AUS">Australia</option>
              </select>
            </div>
          </div>
        </div>
      )}
    </>
  )
  
  // Render order review
  const renderOrderReview = () => (
    <>
      <h2 className="text-xl font-bold mb-6">Review Your Order</h2>
      
      {/* Order items */}
      <div className="border rounded-lg overflow-hidden mb-6">
        <table className="min-w-full divide-y divide-neutral-200">
          <thead className="bg-neutral-50">
            <tr>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">
                Product
              </th>
              <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-neutral-500 uppercase tracking-wider">
                Quantity
              </th>
              <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-neutral-500 uppercase tracking-wider">
                Price
              </th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-neutral-200">
            {items.map((item) => (
              <tr key={item.id}>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="flex items-center">
                    <div className="h-12 w-12 flex-shrink-0">
                      <img 
                        className="h-12 w-12 object-cover rounded-md" 
                        src={item.image} 
                        alt={item.name} 
                      />
                    </div>
                    <div className="ml-4">
                      <div className="text-sm font-medium text-neutral-900">{item.name}</div>
                    </div>
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-right text-sm text-neutral-500">
                  {item.quantity}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-right text-sm text-neutral-900">
                  ${(item.price * item.quantity).toFixed(2)}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      
      {/* Order summary */}
      <div className="border rounded-lg overflow-hidden mb-6">
        <div className="bg-neutral-50 px-6 py-3 border-b">
          <h3 className="text-sm font-medium text-neutral-700">Order Summary</h3>
        </div>
        <div className="bg-white px-6 py-4 space-y-2">
          <div className="flex justify-between text-sm">
            <span className="text-neutral-600">Subtotal</span>
            <span className="text-neutral-900">${totalAmount.toFixed(2)}</span>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-neutral-600">Shipping</span>
            <span className="text-neutral-900">
              {shipping === 0 ? 'Free' : `$${shipping.toFixed(2)}`}
            </span>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-neutral-600">Tax</span>
            <span className="text-neutral-900">${tax.toFixed(2)}</span>
          </div>
          <div className="flex justify-between font-medium pt-2 border-t">
            <span>Total</span>
            <span>${orderTotal.toFixed(2)}</span>
          </div>
        </div>
      </div>
      
      {/* Shipping address */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
        <div className="border rounded-lg overflow-hidden">
          <div className="bg-neutral-50 px-6 py-3 border-b">
            <h3 className="text-sm font-medium text-neutral-700">Shipping Address</h3>
          </div>
          <div className="bg-white px-6 py-4 text-sm">
            <p className="font-medium">{shippingAddress.fullName}</p>
            <p>{shippingAddress.addressLine1}</p>
            {shippingAddress.addressLine2 && <p>{shippingAddress.addressLine2}</p>}
            <p>{shippingAddress.city}, {shippingAddress.state} {shippingAddress.zipCode}</p>
            <p>{shippingAddress.country}</p>
            <p>Phone: {shippingAddress.phone}</p>
          </div>
        </div>
        
        {/* Billing address */}
        <div className="border rounded-lg overflow-hidden">
          <div className="bg-neutral-50 px-6 py-3 border-b">
            <h3 className="text-sm font-medium text-neutral-700">Billing Address</h3>
          </div>
          <div className="bg-white px-6 py-4 text-sm">
            <p className="font-medium">{billingAddress.fullName}</p>
            <p>{billingAddress.addressLine1}</p>
            {billingAddress.addressLine2 && <p>{billingAddress.addressLine2}</p>}
            <p>{billingAddress.city}, {billingAddress.state} {billingAddress.zipCode}</p>
            <p>{billingAddress.country}</p>
            <p>Phone: {billingAddress.phone}</p>
          </div>
        </div>
      </div>
      
      {/* Payment method */}
      <div className="border rounded-lg overflow-hidden mb-6">
        <div className="bg-neutral-50 px-6 py-3 border-b">
          <h3 className="text-sm font-medium text-neutral-700">Payment Method</h3>
        </div>
        <div className="bg-white px-6 py-4 text-sm">
          <p className="flex items-center">
            {paymentMethod === 'credit-card' ? (
              <>
                <FiCreditCard className="mr-2" />
                Credit/Debit Card
              </>
            ) : (
              'PayPal'
            )}
          </p>
        </div>
      </div>
    </>
  )
  
  // Render order confirmation
  const renderOrderConfirmation = () => (
    <div className="text-center py-8">
      <div className="w-16 h-16 bg-success-500 rounded-full flex items-center justify-center mx-auto mb-4">
        <FiCheckCircle className="text-white" size={32} />
      </div>
      <h2 className="text-2xl font-bold mb-2">Thank You for Your Order!</h2>
      <p className="text-neutral-600 mb-6">
        Your order has been placed successfully and will be processed as soon as possible.
      </p>
      <div className="bg-neutral-50 rounded-lg p-6 mb-6">
        <p className="text-sm text-neutral-600">Order Number</p>
        <p className="text-lg font-medium">{orderId}</p>
      </div>
      <p className="text-neutral-600 mb-6">
        A confirmation email has been sent to your email address.
      </p>
      <div className="flex flex-col sm:flex-row gap-4 justify-center">
        <button
          onClick={() => navigate('/orders')}
          className="btn btn-primary"
        >
          View Order
        </button>
        <button
          onClick={() => navigate('/products')}
          className="btn btn-outline"
        >
          Continue Shopping
        </button>
      </div>
    </div>
  )
  
  // Render current step
  const renderStep = () => {
    switch (step) {
      case STEPS.SHIPPING:
        return renderShippingForm()
      case STEPS.PAYMENT:
        return renderPaymentForm()
      case STEPS.REVIEW:
        return renderOrderReview()
      case STEPS.CONFIRMATION:
        return renderOrderConfirmation()
      default:
        return null
    }
  }
  
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-8">Checkout</h1>
      
      {/* Checkout progress */}
      {step !== STEPS.CONFIRMATION && (
        <div className="mb-8">
          <div className="flex items-center justify-between">
            <div className="flex flex-col items-center">
              <div className={`w-8 h-8 rounded-full flex items-center justify-center mb-1 ${
                step === STEPS.SHIPPING || step === STEPS.PAYMENT || step === STEPS.REVIEW
                  ? 'bg-primary-500 text-white' 
                  : 'bg-neutral-200 text-neutral-600'
              }`}>
                1
              </div>
              <span className="text-sm">Shipping</span>
            </div>
            <div className="flex-1 h-px bg-neutral-200 mx-2"></div>
            <div className="flex flex-col items-center">
              <div className={`w-8 h-8 rounded-full flex items-center justify-center mb-1 ${
                step === STEPS.PAYMENT || step === STEPS.REVIEW
                  ? 'bg-primary-500 text-white' 
                  : 'bg-neutral-200 text-neutral-600'
              }`}>
                2
              </div>
              <span className="text-sm">Payment</span>
            </div>
            <div className="flex-1 h-px bg-neutral-200 mx-2"></div>
            <div className="flex flex-col items-center">
              <div className={`w-8 h-8 rounded-full flex items-center justify-center mb-1 ${
                step === STEPS.REVIEW
                  ? 'bg-primary-500 text-white' 
                  : 'bg-neutral-200 text-neutral-600'
              }`}>
                3
              </div>
              <span className="text-sm">Review</span>
            </div>
          </div>
        </div>
      )}
      
      <div className="flex flex-col lg:flex-row gap-8">
        {/* Main checkout form */}
        <div className="lg:w-2/3">
          <div className="bg-white rounded-lg shadow-sm p-6">
            {renderStep()}
            
            {/* Action buttons */}
            {step !== STEPS.CONFIRMATION && (
              <div className="mt-8 flex justify-between">
                {step !== STEPS.SHIPPING ? (
                  <button 
                    onClick={handleBack}
                    className="btn btn-outline"
                  >
                    Back
                  </button>
                ) : (
                  <div></div>
                )}
                
                {step === STEPS.REVIEW ? (
                  <button 
                    onClick={handlePlaceOrder}
                    className="btn btn-primary"
                    disabled={loading}
                  >
                    {loading ? 'Processing...' : 'Place Order'}
                  </button>
                ) : (
                  <button 
                    onClick={handleContinue}
                    className="btn btn-primary"
                  >
                    Continue
                  </button>
                )}
              </div>
            )}
          </div>
        </div>
        
        {/* Order summary */}
        {step !== STEPS.CONFIRMATION && (
          <div className="lg:w-1/3">
            <div className="bg-white rounded-lg shadow-sm p-6 sticky top-24">
              <h2 className="text-lg font-bold mb-4">Order Summary</h2>
              
              <div className="max-h-64 overflow-y-auto mb-4">
                {items.map(item => (
                  <div key={item.id} className="flex items-center gap-4 py-2 border-b">
                    <img
                      src={item.image}
                      alt={item.name}
                      className="w-16 h-16 object-cover rounded-md"
                    />
                    <div className="flex-1">
                      <h4 className="text-sm font-medium">{item.name}</h4>
                      <div className="flex justify-between items-center mt-1">
                        <p className="text-sm text-neutral-600">Qty: {item.quantity}</p>
                        <p className="text-sm font-medium">${(item.price * item.quantity).toFixed(2)}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
              
              <div className="space-y-2 mb-4">
                <div className="flex justify-between">
                  <span className="text-neutral-600">Subtotal</span>
                  <span>${totalAmount.toFixed(2)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-neutral-600">Shipping</span>
                  <span>
                    {shipping === 0 ? 'Free' : `$${shipping.toFixed(2)}`}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-neutral-600">Tax</span>
                  <span>${tax.toFixed(2)}</span>
                </div>
              </div>
              
              <div className="border-t pt-4 flex justify-between font-bold">
                <span>Total</span>
                <span>${orderTotal.toFixed(2)}</span>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}

export default CheckoutPage