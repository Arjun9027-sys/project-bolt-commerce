import { useEffect, useState } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { useSearchParams } from 'react-router-dom'
import { FiFilter, FiGrid, FiList, FiChevronDown } from 'react-icons/fi'

import { fetchProducts, fetchCategories, setFilteredProducts } from '../store/slices/productSlice'
import ProductCard from '../components/products/ProductCard'
import Loading from '../components/common/Loading'

const ProductsPage = () => {
  const dispatch = useDispatch()
  const [searchParams, setSearchParams] = useSearchParams()
  const { items, filteredItems, categories, loading } = useSelector(state => state.products)
  
  // Local state
  const [viewMode, setViewMode] = useState('grid')
  const [showFilters, setShowFilters] = useState(true)
  const [priceRange, setPriceRange] = useState([0, 3000])
  const [selectedCategories, setSelectedCategories] = useState([])
  const [sortBy, setSortBy] = useState('featured')
  
  // Get query params
  const categoryParam = searchParams.get('category')
  const searchParam = searchParams.get('search')
  
  useEffect(() => {
    dispatch(fetchProducts())
    dispatch(fetchCategories())
  }, [dispatch])
  
  // Handle initial category parameter
  useEffect(() => {
    if (categoryParam && categories.includes(categoryParam) && !selectedCategories.includes(categoryParam)) {
      setSelectedCategories([categoryParam])
    }
  }, [categoryParam, categories, selectedCategories])
  
  // Apply filters and sorting
  useEffect(() => {
    if (items.length === 0) return
    
    let filtered = [...items]
    
    // Apply category filter
    if (selectedCategories.length > 0) {
      filtered = filtered.filter(item => selectedCategories.includes(item.category))
    }
    
    // Apply price filter
    filtered = filtered.filter(
      item => item.price >= priceRange[0] && item.price <= priceRange[1]
    )
    
    // Apply search filter
    if (searchParam) {
      const query = searchParam.toLowerCase()
      filtered = filtered.filter(
        item => 
          item.name.toLowerCase().includes(query) || 
          item.description.toLowerCase().includes(query) ||
          item.category.toLowerCase().includes(query)
      )
    }
    
    // Apply sorting
    switch (sortBy) {
      case 'price-low':
        filtered.sort((a, b) => a.price - b.price)
        break
      case 'price-high':
        filtered.sort((a, b) => b.price - a.price)
        break
      case 'name-asc':
        filtered.sort((a, b) => a.name.localeCompare(b.name))
        break
      case 'name-desc':
        filtered.sort((a, b) => b.name.localeCompare(a.name))
        break
      case 'rating':
        filtered.sort((a, b) => b.rating - a.rating)
        break
      default:
        // Keep original order for 'featured'
        break
    }
    
    dispatch(setFilteredProducts(filtered))
  }, [items, selectedCategories, priceRange, sortBy, searchParam, dispatch])
  
  // Handle category selection
  const handleCategoryChange = (category) => {
    setSelectedCategories(prev => {
      if (prev.includes(category)) {
        return prev.filter(c => c !== category)
      } else {
        return [...prev, category]
      }
    })
  }
  
  // Handle price range change
  const handlePriceChange = (e, index) => {
    const value = parseInt(e.target.value)
    setPriceRange(prev => {
      const newRange = [...prev]
      newRange[index] = value
      return newRange
    })
  }
  
  // Handle sort change
  const handleSortChange = (e) => {
    setSortBy(e.target.value)
  }
  
  // Toggle filters on mobile
  const toggleFilters = () => {
    setShowFilters(prev => !prev)
  }
  
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2">
          {searchParam 
            ? `Search results for "${searchParam}"` 
            : selectedCategories.length === 1 
              ? selectedCategories[0] 
              : 'All Products'}
        </h1>
        <p className="text-neutral-600">
          {filteredItems.length} products found
        </p>
      </div>
      
      <div className="flex flex-col lg:flex-row gap-8">
        {/* Mobile filter toggle */}
        <div className="lg:hidden mb-4">
          <button
            onClick={toggleFilters}
            className="flex items-center gap-2 text-neutral-800 font-medium"
          >
            <FiFilter size={18} />
            <span>Filters</span>
            <FiChevronDown className={`transition-transform ${showFilters ? 'rotate-180' : ''}`} />
          </button>
        </div>
        
        {/* Filters */}
        <div className={`lg:w-1/4 ${showFilters ? 'block' : 'hidden lg:block'}`}>
          <div className="bg-white rounded-lg shadow-sm p-6">
            <h2 className="text-lg font-bold mb-4">Filters</h2>
            
            {/* Categories */}
            <div className="mb-6">
              <h3 className="font-medium mb-3">Categories</h3>
              <div className="space-y-2">
                {categories.map((category, index) => (
                  <div key={index} className="flex items-center">
                    <input
                      type="checkbox"
                      id={`category-${index}`}
                      checked={selectedCategories.includes(category)}
                      onChange={() => handleCategoryChange(category)}
                      className="rounded text-primary-500 focus:ring-primary-500"
                    />
                    <label htmlFor={`category-${index}`} className="ml-2 text-neutral-700">
                      {category}
                    </label>
                  </div>
                ))}
              </div>
            </div>
            
            {/* Price Range */}
            <div>
              <h3 className="font-medium mb-3">Price Range</h3>
              <div className="space-y-4">
                <div className="flex justify-between">
                  <span>${priceRange[0]}</span>
                  <span>${priceRange[1]}</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="3000"
                  step="50"
                  value={priceRange[0]}
                  onChange={(e) => handlePriceChange(e, 0)}
                  className="w-full"
                />
                <input
                  type="range"
                  min="0"
                  max="3000"
                  step="50"
                  value={priceRange[1]}
                  onChange={(e) => handlePriceChange(e, 1)}
                  className="w-full"
                />
              </div>
            </div>
          </div>
        </div>
        
        {/* Products */}
        <div className="lg:w-3/4">
          {/* Sorting and view options */}
          <div className="flex justify-between items-center mb-6">
            <div className="flex-1">
              <select
                value={sortBy}
                onChange={handleSortChange}
                className="border border-neutral-300 rounded-md p-2 focus:border-primary-500 focus:ring-2 focus:ring-primary-500 focus:outline-none"
              >
                <option value="featured">Featured</option>
                <option value="price-low">Price: Low to High</option>
                <option value="price-high">Price: High to Low</option>
                <option value="name-asc">Name: A to Z</option>
                <option value="name-desc">Name: Z to A</option>
                <option value="rating">Top Rated</option>
              </select>
            </div>
            
            {/* View mode toggle */}
            <div className="hidden sm:flex items-center gap-2">
              <button
                onClick={() => setViewMode('grid')}
                className={`p-2 rounded ${viewMode === 'grid' ? 'bg-primary-100 text-primary-600' : 'text-neutral-600'}`}
                aria-label="Grid view"
              >
                <FiGrid size={20} />
              </button>
              <button
                onClick={() => setViewMode('list')}
                className={`p-2 rounded ${viewMode === 'list' ? 'bg-primary-100 text-primary-600' : 'text-neutral-600'}`}
                aria-label="List view"
              >
                <FiList size={20} />
              </button>
            </div>
          </div>
          
          {/* Product grid/list */}
          {loading ? (
            <Loading />
          ) : filteredItems.length === 0 ? (
            <div className="bg-white rounded-lg shadow-sm p-8 text-center">
              <h3 className="text-xl font-bold mb-2">No products found</h3>
              <p className="text-neutral-600 mb-4">
                Try adjusting your filters or search term.
              </p>
              <button
                onClick={() => {
                  setSelectedCategories([])
                  setPriceRange([0, 3000])
                  setSearchParams({})
                }}
                className="btn btn-primary"
              >
                Clear Filters
              </button>
            </div>
          ) : (
            <div className={`
              ${viewMode === 'grid' 
                ? 'grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6' 
                : 'space-y-4'
              }
            `}>
              {filteredItems.map(product => (
                <div key={product.id} className={viewMode === 'list' ? 'bg-white rounded-lg shadow-sm' : ''}>
                  {viewMode === 'grid' ? (
                    <ProductCard product={product} />
                  ) : (
                    <div className="flex flex-col sm:flex-row">
                      <div className="sm:w-1/3 relative">
                        <img
                          src={product.image}
                          alt={product.name}
                          className="w-full h-48 sm:h-full object-cover rounded-t-lg sm:rounded-l-lg sm:rounded-r-none"
                        />
                      </div>
                      <div className="p-4 sm:w-2/3 flex flex-col">
                        <div className="flex-1">
                          <p className="text-sm text-neutral-500 mb-1">{product.category}</p>
                          <h3 className="text-lg font-medium text-neutral-900 mb-2">{product.name}</h3>
                          <div className="flex items-center gap-1 mb-2">
                            <FiStar className="text-warning-500 fill-current" />
                            <span className="text-sm font-medium">{product.rating}</span>
                          </div>
                          <p className="text-neutral-600 mb-4 line-clamp-2">{product.description}</p>
                        </div>
                        <div className="flex items-center justify-between">
                          <span className="text-xl font-bold text-neutral-900">
                            ${product.price.toFixed(2)}
                          </span>
                          <button
                            onClick={(e) => {
                              e.preventDefault()
                              e.stopPropagation()
                              dispatch(addToCart({
                                id: product.id,
                                name: product.name,
                                price: product.price,
                                image: product.image,
                                quantity: 1,
                              }))
                              dispatch(addNotification({
                                type: 'success',
                                message: `${product.name} added to cart!`,
                              }))
                            }}
                            className="btn btn-primary"
                          >
                            Add to Cart
                          </button>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

export default ProductsPage