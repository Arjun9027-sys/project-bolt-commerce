import { useEffect } from 'react'
import { Link } from 'react-router-dom'
import { useDispatch, useSelector } from 'react-redux'
import Slider from 'react-slick'
import 'slick-carousel/slick/slick.css'
import 'slick-carousel/slick/slick-theme.css'

import { fetchProducts, fetchCategories } from '../store/slices/productSlice'
import ProductCard from '../components/products/ProductCard'
import FeaturedCategory from '../components/home/FeaturedCategory'
import Loading from '../components/common/Loading'

const HomePage = () => {
  const dispatch = useDispatch()
  const { items, categories, loading } = useSelector(state => state.products)
  
  useEffect(() => {
    dispatch(fetchProducts())
    dispatch(fetchCategories())
  }, [dispatch])
  
  // Hero slider settings
  const heroSliderSettings = {
    dots: true,
    infinite: true,
    speed: 500,
    slidesToShow: 1,
    slidesToScroll: 1,
    autoplay: true,
    autoplaySpeed: 5000,
    arrows: false,
  }
  
  // Featured products slider settings
  const productsSliderSettings = {
    dots: false,
    infinite: false,
    speed: 500,
    slidesToShow: 4,
    slidesToScroll: 1,
    responsive: [
      {
        breakpoint: 1024,
        settings: {
          slidesToShow: 3,
        }
      },
      {
        breakpoint: 768,
        settings: {
          slidesToShow: 2,
        }
      },
      {
        breakpoint: 640,
        settings: {
          slidesToShow: 1,
        }
      }
    ]
  }
  
  return (
    <div>
      {/* Hero Slider */}
      <section className="relative">
        <Slider {...heroSliderSettings}>
          <div>
            <div className="relative h-[500px] md:h-[600px] bg-gradient-to-r from-primary-900 to-primary-700 flex items-center">
              <div className="container mx-auto px-4 flex flex-col md:flex-row items-center">
                <div className="md:w-1/2 text-white z-10">
                  <h1 className="text-4xl md:text-5xl font-bold mb-4">iPhone 15 Pro Max</h1>
                  <p className="text-xl mb-6">Experience the future with our most powerful iPhone ever.</p>
                  <Link to="/products/1" className="btn bg-white text-primary-900 hover:bg-neutral-100">
                    Shop Now
                  </Link>
                </div>
                <div className="md:w-1/2 mt-8 md:mt-0">
                  <img 
                    src="https://images.pexels.com/photos/5750001/pexels-photo-5750001.jpeg"
                    alt="iPhone 15 Pro Max" 
                    className="max-h-[400px] object-contain mx-auto"
                  />
                </div>
              </div>
            </div>
          </div>
          <div>
            <div className="relative h-[500px] md:h-[600px] bg-gradient-to-r from-accent-900 to-accent-700 flex items-center">
              <div className="container mx-auto px-4 flex flex-col md:flex-row items-center">
                <div className="md:w-1/2 text-white z-10">
                  <h1 className="text-4xl md:text-5xl font-bold mb-4">MacBook Pro 16"</h1>
                  <p className="text-xl mb-6">Unleash your creativity with unprecedented power.</p>
                  <Link to="/products/2" className="btn bg-white text-accent-900 hover:bg-neutral-100">
                    Shop Now
                  </Link>
                </div>
                <div className="md:w-1/2 mt-8 md:mt-0">
                  <img 
                    src="https://images.pexels.com/photos/303383/pexels-photo-303383.jpeg"
                    alt="MacBook Pro" 
                    className="max-h-[400px] object-contain mx-auto"
                  />
                </div>
              </div>
            </div>
          </div>
        </Slider>
      </section>
      
      {/* Featured Categories */}
      <section className="py-16 bg-neutral-50">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">Featured Categories</h2>
          
          {loading ? (
            <Loading />
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {categories.slice(0, 4).map((category, index) => (
                <FeaturedCategory 
                  key={index} 
                  category={category} 
                  index={index}
                />
              ))}
            </div>
          )}
        </div>
      </section>
      
      {/* Featured Products */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="flex justify-between items-center mb-12">
            <h2 className="text-3xl font-bold">New Arrivals</h2>
            <Link to="/products" className="text-primary-600 hover:text-primary-700 font-medium">
              View All
            </Link>
          </div>
          
          {loading ? (
            <Loading />
          ) : (
            <Slider {...productsSliderSettings}>
              {items.map(product => (
                <div key={product.id} className="px-2">
                  <ProductCard product={product} />
                </div>
              ))}
            </Slider>
          )}
        </div>
      </section>
      
      {/* Promotion Banner */}
      <section className="py-16 bg-secondary-50">
        <div className="container mx-auto px-4">
          <div className="flex flex-col lg:flex-row items-center bg-white rounded-lg shadow-sm overflow-hidden">
            <div className="lg:w-1/2 p-8 lg:p-16">
              <h2 className="text-3xl font-bold mb-4">Save up to 30% on Accessories</h2>
              <p className="text-lg text-neutral-600 mb-6">
                Limited time offer on iPhone cases, AirPods, and more. Upgrade your tech game today!
              </p>
              <Link to="/products?category=Accessories" className="btn btn-primary">
                Shop Accessories
              </Link>
            </div>
            <div className="lg:w-1/2">
              <img 
                src="https://images.pexels.com/photos/3780681/pexels-photo-3780681.jpeg" 
                alt="Accessories" 
                className="w-full h-64 lg:h-96 object-cover"
              />
            </div>
          </div>
        </div>
      </section>
      
      {/* Benefits */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="text-center p-6">
              <div className="w-16 h-16 bg-primary-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-primary-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                </svg>
              </div>
              <h3 className="text-xl font-bold mb-2">Premium Quality</h3>
              <p className="text-neutral-600">
                All our products are original and come with official warranty.
              </p>
            </div>
            
            <div className="text-center p-6">
              <div className="w-16 h-16 bg-primary-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-primary-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
              </div>
              <h3 className="text-xl font-bold mb-2">Fast Shipping</h3>
              <p className="text-neutral-600">
                Get your products delivered within 2-3 business days.
              </p>
            </div>
            
            <div className="text-center p-6">
              <div className="w-16 h-16 bg-primary-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-primary-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
                </svg>
              </div>
              <h3 className="text-xl font-bold mb-2">Secure Payments</h3>
              <p className="text-neutral-600">
                Shop with confidence with our secure payment options.
              </p>
            </div>
            
            <div className="text-center p-6">
              <div className="w-16 h-16 bg-primary-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-primary-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 10h10a8 8 0 018 8v2M3 10l6 6m-6-6l6-6" />
                </svg>
              </div>
              <h3 className="text-xl font-bold mb-2">Easy Returns</h3>
              <p className="text-neutral-600">
                30-day hassle-free return policy on all products.
              </p>
            </div>
          </div>
        </div>
      </section>
      
      {/* Newsletter */}
      <section className="py-16 bg-primary-900 text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-2">Join Our Newsletter</h2>
          <p className="text-neutral-200 mb-8 max-w-2xl mx-auto">
            Subscribe to our newsletter and be the first to know about new products, exclusive offers, and more.
          </p>
          <form className="max-w-md mx-auto flex">
            <input
              type="email"
              placeholder="Your email address"
              className="flex-1 px-4 py-3 rounded-l-md text-neutral-900 focus:outline-none"
              required
            />
            <button
              type="submit"
              className="px-6 py-3 bg-accent-500 hover:bg-accent-600 text-white font-medium rounded-r-md transition-colors"
            >
              Subscribe
            </button>
          </form>
        </div>
      </section>
    </div>
  )
}

export default HomePage