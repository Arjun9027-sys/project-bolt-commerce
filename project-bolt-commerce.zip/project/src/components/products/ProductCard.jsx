import { Link } from 'react-router-dom'
import { useDispatch } from 'react-redux'
import { FiHeart, FiShoppingCart, FiStar } from 'react-icons/fi'

import { addToCart } from '../../store/slices/cartSlice'
import { addNotification } from '../../store/slices/uiSlice'

const ProductCard = ({ product }) => {
  const dispatch = useDispatch()
  
  // Handle add to cart
  const handleAddToCart = (e) => {
    e.preventDefault()
    e.stopPropagation()
    
    dispatch(addToCart({
      id: product.id,
      name: product.name,
      price: product.price,
      image: product.image,
      quantity: 1,
    }))
    
    dispatch(addNotification({
      type: 'success',
      message: `${product.name} added to cart!`,
    }))
  }
  
  // Handle add to wishlist
  const handleAddToWishlist = (e) => {
    e.preventDefault()
    e.stopPropagation()
    
    dispatch(addNotification({
      type: 'info',
      message: `${product.name} added to wishlist!`,
    }))
  }
  
  return (
    <Link 
      to={`/products/${product.id}`} 
      className="group block"
    >
      <div className="relative overflow-hidden bg-white rounded-lg shadow-sm transition-all duration-300 hover:shadow-md h-full flex flex-col">
        {/* Product image */}
        <div className="relative pt-[100%] bg-neutral-100">
          <img
            src={product.image}
            alt={product.name}
            className="absolute inset-0 w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
          />
          
          {/* Action buttons */}
          <div className="absolute bottom-2 right-2 flex flex-col gap-2 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
            <button
              onClick={handleAddToWishlist}
              className="p-2 bg-white rounded-full shadow hover:text-primary-500 transition-colors"
              aria-label="Add to wishlist"
            >
              <FiHeart size={20} />
            </button>
            <button
              onClick={handleAddToCart}
              className="p-2 bg-white rounded-full shadow hover:text-primary-500 transition-colors"
              aria-label="Add to cart"
            >
              <FiShoppingCart size={20} />
            </button>
          </div>
        </div>
        
        {/* Product info */}
        <div className="p-4 flex flex-col flex-1">
          <div className="flex-1">
            <p className="text-sm text-neutral-500 mb-1">{product.category}</p>
            <h3 className="font-medium text-neutral-900 mb-1 line-clamp-2">{product.name}</h3>
            
            {/* Rating */}
            <div className="flex items-center gap-1 mb-2">
              <FiStar className="text-warning-500 fill-current" />
              <span className="text-sm font-medium">
                {product.rating}
              </span>
            </div>
          </div>
          
          {/* Price */}
          <div className="mt-2 flex items-center justify-between">
            <span className="text-lg font-bold text-neutral-900">
              ${product.price.toFixed(2)}
            </span>
            <span className={`text-xs px-2 py-1 rounded ${product.countInStock > 0 ? 'bg-success-500 bg-opacity-10 text-success-500' : 'bg-error-500 bg-opacity-10 text-error-500'}`}>
              {product.countInStock > 0 ? 'In Stock' : 'Out of Stock'}
            </span>
          </div>
        </div>
      </div>
    </Link>
  )
}

export default ProductCard