import { useState, useEffect } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { useDispatch, useSelector } from 'react-redux'
import { FiSearch, FiShoppingCart, FiUser, FiMenu, FiHeart } from 'react-icons/fi'

import { 
  toggleMobileMenu, 
  toggleSearch, 
  toggleCartDrawer 
} from '../../store/slices/uiSlice'

const Header = () => {
  const dispatch = useDispatch()
  const navigate = useNavigate()
  const { totalQuantity } = useSelector(state => state.cart)
  const { isAuthenticated } = useSelector(state => state.auth)
  const [isScrolled, setIsScrolled] = useState(false)
  const { categories } = useSelector(state => state.products)
  
  // Handle scroll effect for header
  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50)
    }
    
    window.addEventListener('scroll', handleScroll)
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])
  
  return (
    <header 
      className={`sticky top-0 z-40 w-full transition-all duration-300 ${
        isScrolled ? 'bg-white shadow-md' : 'bg-white/80 backdrop-blur-md'
      }`}
    >
      {/* Top bar */}
      <div className="bg-primary-900 text-white text-xs py-2 text-center">
        <p>Free shipping on orders over $50 | 30-day returns</p>
      </div>
      
      {/* Main header */}
      <div className="container mx-auto px-4 py-4 flex items-center justify-between">
        {/* Mobile menu button */}
        <button 
          className="lg:hidden flex items-center text-neutral-700"
          onClick={() => dispatch(toggleMobileMenu())}
          aria-label="Menu"
        >
          <FiMenu size={24} />
        </button>
        
        {/* Logo */}
        <Link to="/" className="text-2xl font-bold text-primary-600">
          AppleZone
        </Link>
        
        {/* Desktop Navigation */}
        <nav className="hidden lg:flex items-center space-x-8">
          <Link to="/" className="text-neutral-700 hover:text-primary-500 transition-colors">
            Home
          </Link>
          <Link to="/products" className="text-neutral-700 hover:text-primary-500 transition-colors">
            Products
          </Link>
          <div className="relative group">
            <button className="text-neutral-700 hover:text-primary-500 transition-colors flex items-center gap-1">
              Categories
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7"></path>
              </svg>
            </button>
            <div className="absolute left-0 mt-2 w-56 rounded-md shadow-lg bg-white ring-1 ring-black ring-opacity-5 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-200 z-50">
              <div className="py-1">
                {categories.map((category, index) => (
                  <Link
                    key={index}
                    to={`/products?category=${category}`}
                    className="block px-4 py-2 text-sm text-neutral-700 hover:bg-neutral-100"
                  >
                    {category}
                  </Link>
                ))}
              </div>
            </div>
          </div>
          <Link to="/about" className="text-neutral-700 hover:text-primary-500 transition-colors">
            About
          </Link>
          <Link to="/contact" className="text-neutral-700 hover:text-primary-500 transition-colors">
            Contact
          </Link>
        </nav>
        
        {/* Header Actions */}
        <div className="flex items-center space-x-4">
          {/* Search */}
          <button 
            onClick={() => dispatch(toggleSearch())}
            className="text-neutral-700 hover:text-primary-500 transition-colors"
            aria-label="Search"
          >
            <FiSearch size={20} />
          </button>
          
          {/* Wishlist */}
          <Link 
            to="/wishlist" 
            className="text-neutral-700 hover:text-primary-500 transition-colors hidden sm:block"
            aria-label="Wishlist"
          >
            <FiHeart size={20} />
          </Link>
          
          {/* User Account */}
          <Link 
            to={isAuthenticated ? "/profile" : "/login"} 
            className="text-neutral-700 hover:text-primary-500 transition-colors"
            aria-label="Account"
          >
            <FiUser size={20} />
          </Link>
          
          {/* Cart */}
          <button 
            onClick={() => dispatch(toggleCartDrawer())}
            className="text-neutral-700 hover:text-primary-500 transition-colors relative"
            aria-label="Cart"
          >
            <FiShoppingCart size={20} />
            {totalQuantity > 0 && (
              <span className="absolute -top-2 -right-2 bg-accent-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                {totalQuantity > 99 ? '99+' : totalQuantity}
              </span>
            )}
          </button>
        </div>
      </div>
    </header>
  )
}

export default Header