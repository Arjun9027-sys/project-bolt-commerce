import { useEffect } from 'react'
import { Outlet, useLocation } from 'react-router-dom'
import { useDispatch, useSelector } from 'react-redux'

import Header from './Header'
import Footer from './Footer'
import CartDrawer from '../cart/CartDrawer'
import SearchOverlay from '../common/SearchOverlay'
import Notification from '../common/Notification'
import MobileMenu from './MobileMenu'
import { closeMobileMenu } from '../../store/slices/uiSlice'

const Layout = () => {
  const location = useLocation()
  const dispatch = useDispatch()
  const { mobileMenuOpen, searchOpen, cartDrawerOpen, notifications } = useSelector(state => state.ui)
  
  // Close mobile menu on route change
  useEffect(() => {
    if (mobileMenuOpen) {
      dispatch(closeMobileMenu())
    }
  }, [location.pathname, dispatch, mobileMenuOpen])
  
  return (
    <div className="flex flex-col min-h-screen">
      <Header />
      
      <main className="flex-grow">
        <Outlet />
      </main>
      
      <Footer />
      
      {/* Mobile Menu */}
      {mobileMenuOpen && <MobileMenu />}
      
      {/* Cart Drawer */}
      {cartDrawerOpen && <CartDrawer />}
      
      {/* Search Overlay */}
      {searchOpen && <SearchOverlay />}
      
      {/* Notifications */}
      <div className="fixed bottom-5 right-5 z-50 flex flex-col gap-2">
        {notifications.map(notification => (
          <Notification
            key={notification.id}
            id={notification.id}
            type={notification.type}
            message={notification.message}
          />
        ))}
      </div>
    </div>
  )
}

export default Layout