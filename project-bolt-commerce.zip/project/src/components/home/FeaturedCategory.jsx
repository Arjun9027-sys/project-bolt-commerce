import { Link } from 'react-router-dom'

const FeaturedCategory = ({ category, index }) => {
  // Get background color based on index
  const getBgColor = () => {
    const colors = [
      'bg-primary-100',
      'bg-secondary-100',
      'bg-accent-100',
      'bg-success-500 bg-opacity-10',
    ]
    return colors[index % colors.length]
  }
  
  // Get image based on category
  const getImage = () => {
    switch (category) {
      case 'Smartphones':
        return 'https://images.pexels.com/photos/5750001/pexels-photo-5750001.jpeg'
      case 'Laptops':
        return 'https://images.pexels.com/photos/303383/pexels-photo-303383.jpeg'
      case 'Tablets':
        return 'https://images.pexels.com/photos/1334597/pexels-photo-1334597.jpeg'
      case 'Audio':
        return 'https://images.pexels.com/photos/3780681/pexels-photo-3780681.jpeg'
      case 'Wearables':
        return 'https://images.pexels.com/photos/437037/pexels-photo-437037.jpeg'
      case 'Smart Home':
        return 'https://images.pexels.com/photos/7052018/pexels-photo-7052018.jpeg'
      default:
        return 'https://images.pexels.com/photos/5750001/pexels-photo-5750001.jpeg'
    }
  }
  
  return (
    <Link 
      to={`/products?category=${category}`}
      className={`rounded-lg overflow-hidden shadow-sm hover:shadow-md transition-shadow group ${getBgColor()}`}
    >
      <div className="p-6 flex flex-col">
        <h3 className="text-xl font-bold mb-2 text-neutral-900">{category}</h3>
        <p className="text-neutral-600 mb-4">Shop the latest {category.toLowerCase()}</p>
        <div className="mt-auto">
          <img 
            src={getImage()} 
            alt={category}
            className="w-full h-48 object-contain transform group-hover:scale-105 transition-transform duration-300"
          />
        </div>
      </div>
    </Link>
  )
}

export default FeaturedCategory