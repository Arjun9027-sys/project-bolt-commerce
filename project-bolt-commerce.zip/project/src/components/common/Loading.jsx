import React from 'react'

const Loading = () => {
  return (
    <div className="flex items-center justify-center min-h-[200px]">
      <div className="relative">
        <div className="h-16 w-16 rounded-full border-4 border-neutral-200"></div>
        <div className="h-16 w-16 rounded-full border-4 border-t-primary-500 animate-spin absolute top-0 left-0"></div>
      </div>
    </div>
  )
}

export default Loading