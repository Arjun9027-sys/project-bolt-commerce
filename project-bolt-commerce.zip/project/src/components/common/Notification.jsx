import { useEffect } from 'react'
import { FiX, FiCheckCircle, FiAlertCircle, FiInfo } from 'react-icons/fi'
import { useDispatch } from 'react-redux'
import { removeNotification } from '../../store/slices/uiSlice'

const Notification = ({ id, type = 'info', message }) => {
  const dispatch = useDispatch()
  
  // Auto dismiss after 5 seconds
  useEffect(() => {
    const timer = setTimeout(() => {
      dispatch(removeNotification(id))
    }, 5000)
    
    return () => clearTimeout(timer)
  }, [id, dispatch])
  
  // Handle close
  const handleClose = () => {
    dispatch(removeNotification(id))
  }
  
  // Icon based on type
  const getIcon = () => {
    switch (type) {
      case 'success':
        return <FiCheckCircle size={20} className="text-success-500" />
      case 'error':
        return <FiAlertCircle size={20} className="text-error-500" />
      case 'warning':
        return <FiAlertCircle size={20} className="text-warning-500" />
      default:
        return <FiInfo size={20} className="text-primary-500" />
    }
  }
  
  // Background based on type
  const getBackground = () => {
    switch (type) {
      case 'success':
        return 'bg-success-500 bg-opacity-10 border-success-500'
      case 'error':
        return 'bg-error-500 bg-opacity-10 border-error-500'
      case 'warning':
        return 'bg-warning-500 bg-opacity-10 border-warning-500'
      default:
        return 'bg-primary-500 bg-opacity-10 border-primary-500'
    }
  }
  
  return (
    <div className={`w-80 rounded-lg shadow-lg border-l-4 bg-white p-4 animate-slide-up ${getBackground()}`}>
      <div className="flex items-start">
        <div className="flex-shrink-0">
          {getIcon()}
        </div>
        <div className="ml-3 flex-1">
          <p className="text-sm text-neutral-800">{message}</p>
        </div>
        <button
          onClick={handleClose}
          className="ml-4 text-neutral-400 hover:text-neutral-500"
          aria-label="Close notification"
        >
          <FiX size={18} />
        </button>
      </div>
    </div>
  )
}

export default Notification