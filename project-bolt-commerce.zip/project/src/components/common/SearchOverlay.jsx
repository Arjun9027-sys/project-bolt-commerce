import { useState, useEffect, useRef } from 'react'
import { useNavigate } from 'react-router-dom'
import { FiX, FiSearch } from 'react-icons/fi'
import { useDispatch } from 'react-redux'
import debounce from 'lodash.debounce'

import { toggleSearch } from '../../store/slices/uiSlice'
import api from '../../services/api'

const SearchOverlay = () => {
  const dispatch = useDispatch()
  const navigate = useNavigate()
  const [query, setQuery] = useState('')
  const [results, setResults] = useState([])
  const [loading, setLoading] = useState(false)
  const inputRef = useRef(null)
  
  // Focus input on mount
  useEffect(() => {
    inputRef.current?.focus()
  }, [])
  
  // Handle search with debounce
  const searchProducts = debounce(async (searchQuery) => {
    if (searchQuery.trim().length < 2) {
      setResults([])
      return
    }
    
    setLoading(true)
    try {
      const response = await api.products.search(searchQuery)
      setResults(response.products.slice(0, 5))
    } catch (error) {
      console.error('Search error:', error)
    } finally {
      setLoading(false)
    }
  }, 300)
  
  // Handle input change
  const handleChange = (e) => {
    const value = e.target.value
    setQuery(value)
    searchProducts(value)
  }
  
  // Handle close
  const handleClose = () => {
    dispatch(toggleSearch())
  }
  
  // Handle result click
  const handleResultClick = (id) => {
    navigate(`/products/${id}`)
    handleClose()
  }
  
  // Handle search submit
  const handleSubmit = (e) => {
    e.preventDefault()
    if (query.trim()) {
      navigate(`/products?search=${encodeURIComponent(query.trim())}`)
      handleClose()
    }
  }
  
  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-start justify-center pt-20 animate-fade-in">
      <div className="w-full max-w-2xl bg-white rounded-lg shadow-xl overflow-hidden">
        {/* Search input */}
        <div className="p-4 border-b">
          <form onSubmit={handleSubmit} className="flex items-center gap-2">
            <FiSearch size={20} className="text-neutral-400" />
            <input
              ref={inputRef}
              type="text"
              value={query}
              onChange={handleChange}
              placeholder="Search for products..."
              className="flex-1 py-2 focus:outline-none text-lg"
            />
            <button
              type="button"
              onClick={handleClose}
              className="p-1 rounded-full hover:bg-neutral-100"
              aria-label="Close search"
            >
              <FiX size={24} />
            </button>
          </form>
        </div>
        
        {/* Search results */}
        <div className="max-h-[70vh] overflow-y-auto">
          {loading ? (
            <div className="p-4 text-center">
              <div className="inline-block h-8 w-8 animate-spin rounded-full border-4 border-solid border-primary-500 border-r-transparent"></div>
              <p className="mt-2 text-neutral-500">Searching...</p>
            </div>
          ) : query.trim().length > 0 ? (
            results.length > 0 ? (
              <div className="divide-y">
                {results.map(product => (
                  <div
                    key={product.id}
                    className="p-4 hover:bg-neutral-50 cursor-pointer transition-colors"
                    onClick={() => handleResultClick(product.id)}
                  >
                    <div className="flex items-center gap-3">
                      <img 
                        src={product.image} 
                        alt={product.name} 
                        className="w-16 h-16 object-cover rounded-md"
                      />
                      <div>
                        <h4 className="font-medium">{product.name}</h4>
                        <p className="text-neutral-500">{product.category}</p>
                        <p className="text-primary-600 font-medium">${product.price.toFixed(2)}</p>
                      </div>
                    </div>
                  </div>
                ))}
                <div className="p-4 text-center">
                  <button
                    onClick={handleSubmit}
                    className="text-primary-600 hover:text-primary-700 font-medium transition-colors"
                  >
                    See all results
                  </button>
                </div>
              </div>
            ) : (
              <div className="p-8 text-center">
                <p className="text-neutral-500">No products found for "{query}"</p>
              </div>
            )
          ) : (
            <div className="p-8 text-center">
              <p className="text-neutral-500">Enter at least 2 characters to search</p>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

export default SearchOverlay