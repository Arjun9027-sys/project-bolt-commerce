import { useEffect } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { Link, useNavigate } from 'react-router-dom'
import { FiX, FiPlus, FiMinus, FiTrash2, FiShoppingBag } from 'react-icons/fi'

import { toggleCartDrawer } from '../../store/slices/uiSlice'
import { removeFromCart, updateQuantity } from '../../store/slices/cartSlice'

const CartDrawer = () => {
  const dispatch = useDispatch()
  const navigate = useNavigate()
  const { items, totalQuantity, totalAmount } = useSelector(state => state.cart)
  
  // Close drawer on escape key press
  useEffect(() => {
    const handleEscapeKey = (e) => {
      if (e.key === 'Escape') {
        dispatch(toggleCartDrawer())
      }
    }
    
    document.addEventListener('keydown', handleEscapeKey)
    return () => document.removeEventListener('keydown', handleEscapeKey)
  }, [dispatch])
  
  // Handle close
  const handleClose = () => {
    dispatch(toggleCartDrawer())
  }
  
  // Handle checkout
  const handleCheckout = () => {
    dispatch(toggleCartDrawer())
    navigate('/checkout')
  }
  
  // Handle remove item
  const handleRemoveItem = (id) => {
    dispatch(removeFromCart(id))
  }
  
  // Handle quantity update
  const handleUpdateQuantity = (id, quantity) => {
    dispatch(updateQuantity({ id, quantity }))
  }
  
  return (
    <div className="fixed inset-0 z-50 overflow-hidden">
      <div 
        className="absolute inset-0 bg-black bg-opacity-50 transition-opacity animate-fade-in"
        onClick={handleClose}
      ></div>
      
      <div className="fixed inset-y-0 right-0 max-w-full flex">
        <div className="w-screen max-w-md transform transition-transform duration-300 ease-in-out animate-slide-in">
          <div className="h-full flex flex-col bg-white shadow-xl">
            {/* Header */}
            <div className="px-4 py-6 sm:px-6 bg-primary-600 text-white">
              <div className="flex items-center justify-between">
                <h2 className="text-lg font-medium">Shopping Cart</h2>
                <button
                  type="button"
                  className="text-white hover:text-neutral-200"
                  onClick={handleClose}
                >
                  <span className="sr-only">Close panel</span>
                  <FiX size={24} aria-hidden="true" />
                </button>
              </div>
              <p className="mt-1 text-sm text-neutral-200">
                {totalQuantity === 0
                  ? 'Your cart is empty'
                  : `You have ${totalQuantity} item${totalQuantity !== 1 ? 's' : ''} in your cart`}
              </p>
            </div>
            
            {/* Cart items */}
            <div className="flex-1 py-6 px-4 sm:px-6 overflow-y-auto">
              {items.length === 0 ? (
                <div className="text-center py-16">
                  <FiShoppingBag size={64} className="mx-auto text-neutral-300" />
                  <h3 className="mt-4 text-lg font-medium text-neutral-900">Your cart is empty</h3>
                  <p className="mt-1 text-sm text-neutral-500">
                    Start shopping to add items to your cart
                  </p>
                  <div className="mt-6">
                    <Link
                      to="/products"
                      className="btn btn-primary"
                      onClick={handleClose}
                    >
                      Continue Shopping
                    </Link>
                  </div>
                </div>
              ) : (
                <ul className="divide-y divide-neutral-200">
                  {items.map((item) => (
                    <li key={item.id} className="py-4 flex">
                      <div className="h-24 w-24 flex-shrink-0 overflow-hidden rounded-md border border-neutral-200">
                        <img
                          src={item.image}
                          alt={item.name}
                          className="h-full w-full object-cover object-center"
                        />
                      </div>
                      
                      <div className="ml-4 flex-1 flex flex-col">
                        <div>
                          <div className="flex justify-between text-base font-medium text-neutral-900">
                            <h3>
                              <Link 
                                to={`/products/${item.id}`} 
                                onClick={handleClose}
                              >
                                {item.name}
                              </Link>
                            </h3>
                            <p className="ml-4">${(item.price * item.quantity).toFixed(2)}</p>
                          </div>
                          <p className="mt-1 text-sm text-neutral-500">${item.price.toFixed(2)} each</p>
                        </div>
                        
                        <div className="flex-1 flex items-end justify-between">
                          <div className="flex items-center border rounded">
                            <button
                              type="button"
                              className="p-2 text-neutral-600 hover:text-primary-600"
                              onClick={() => handleUpdateQuantity(item.id, item.quantity - 1)}
                              disabled={item.quantity <= 1}
                            >
                              <FiMinus size={16} />
                            </button>
                            <span className="px-2 py-1 text-neutral-900">{item.quantity}</span>
                            <button
                              type="button"
                              className="p-2 text-neutral-600 hover:text-primary-600"
                              onClick={() => handleUpdateQuantity(item.id, item.quantity + 1)}
                            >
                              <FiPlus size={16} />
                            </button>
                          </div>
                          
                          <button
                            type="button"
                            className="text-error-500 hover:text-error-700"
                            onClick={() => handleRemoveItem(item.id)}
                          >
                            <FiTrash2 size={18} />
                          </button>
                        </div>
                      </div>
                    </li>
                  ))}
                </ul>
              )}
            </div>
            
            {/* Footer */}
            {items.length > 0 && (
              <div className="border-t border-neutral-200 py-6 px-4 sm:px-6">
                <div className="mb-4">
                  <div className="flex justify-between text-base text-neutral-600">
                    <p>Subtotal</p>
                    <p>${totalAmount.toFixed(2)}</p>
                  </div>
                  <div className="flex justify-between text-base text-neutral-600 mt-1">
                    <p>Shipping</p>
                    <p>Calculated at checkout</p>
                  </div>
                  <div className="flex justify-between text-lg font-medium text-neutral-900 mt-4 pt-4 border-t">
                    <p>Total</p>
                    <p>${totalAmount.toFixed(2)}</p>
                  </div>
                </div>
                <div className="mt-6">
                  <button
                    onClick={handleCheckout}
                    className="w-full btn btn-primary py-3"
                  >
                    Checkout
                  </button>
                </div>
                <div className="mt-4 text-center">
                  <button
                    className="text-primary-600 text-sm hover:text-primary-700"
                    onClick={handleClose}
                  >
                    Continue Shopping
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}

export default CartDrawer