import { Navigate } from 'react-router-dom'
import { useSelector } from 'react-redux'

const ProtectedRoute = ({ children }) => {
  const { isAuthenticated, loading } = useSelector(state => state.auth)
  
  // If authentication is being checked, show loading
  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[200px]">
        <div className="relative">
          <div className="h-16 w-16 rounded-full border-4 border-neutral-200"></div>
          <div className="h-16 w-16 rounded-full border-4 border-t-primary-500 animate-spin absolute top-0 left-0"></div>
        </div>
      </div>
    )
  }
  
  // If not authenticated, redirect to login
  if (!isAuthenticated) {
    return <Navigate to="/login" replace />
  }
  
  // If authenticated, render children
  return children
}

export default ProtectedRoute