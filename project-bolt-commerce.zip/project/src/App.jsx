import { Suspense, lazy } from 'react'
import { Routes, Route } from 'react-router-dom'
import { Elements } from '@stripe/react-stripe-js'
import { loadStripe } from '@stripe/stripe-js'

import Layout from './components/layout/Layout'
import HomePage from './pages/HomePage'
import Loading from './components/common/Loading'
import ProtectedRoute from './components/auth/ProtectedRoute'

// Lazy load routes for better performance
const ProductsPage = lazy(() => import('./pages/ProductsPage'))
const ProductDetailPage = lazy(() => import('./pages/ProductDetailPage'))
const CartPage = lazy(() => import('./pages/CartPage'))
const CheckoutPage = lazy(() => import('./pages/CheckoutPage'))
const LoginPage = lazy(() => import('./pages/LoginPage'))
const RegisterPage = lazy(() => import('./pages/RegisterPage'))
const ProfilePage = lazy(() => import('./pages/ProfilePage'))
const OrdersPage = lazy(() => import('./pages/OrdersPage'))
const OrderDetailPage = lazy(() => import('./pages/OrderDetailPage'))
const NotFoundPage = lazy(() => import('./pages/NotFoundPage'))

// Initialize Stripe (replace with your publishable key)
const stripePromise = loadStripe('pk_test_yourStripePublishableKey')

function App() {
  return (
    <Elements stripe={stripePromise}>
      <Routes>
        <Route path="/" element={<Layout />}>
          <Route index element={<HomePage />} />
          
          <Route path="products">
            <Route index element={
              <Suspense fallback={<Loading />}>
                <ProductsPage />
              </Suspense>
            } />
            <Route path=":productId" element={
              <Suspense fallback={<Loading />}>
                <ProductDetailPage />
              </Suspense>
            } />
          </Route>
          
          <Route path="cart" element={
            <Suspense fallback={<Loading />}>
              <CartPage />
            </Suspense>
          } />
          
          <Route path="checkout" element={
            <Suspense fallback={<Loading />}>
              <ProtectedRoute>
                <CheckoutPage />
              </ProtectedRoute>
            </Suspense>
          } />
          
          <Route path="login" element={
            <Suspense fallback={<Loading />}>
              <LoginPage />
            </Suspense>
          } />
          
          <Route path="register" element={
            <Suspense fallback={<Loading />}>
              <RegisterPage />
            </Suspense>
          } />
          
          <Route path="profile" element={
            <Suspense fallback={<Loading />}>
              <ProtectedRoute>
                <ProfilePage />
              </ProtectedRoute>
            </Suspense>
          } />
          
          <Route path="orders">
            <Route index element={
              <Suspense fallback={<Loading />}>
                <ProtectedRoute>
                  <OrdersPage />
                </ProtectedRoute>
              </Suspense>
            } />
            <Route path=":orderId" element={
              <Suspense fallback={<Loading />}>
                <ProtectedRoute>
                  <OrderDetailPage />
                </ProtectedRoute>
              </Suspense>
            } />
          </Route>
          
          <Route path="*" element={
            <Suspense fallback={<Loading />}>
              <NotFoundPage />
            </Suspense>
          } />
        </Route>
      </Routes>
    </Elements>
  )
}

export default App