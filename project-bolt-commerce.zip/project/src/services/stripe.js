import { loadStripe } from '@stripe/stripe-js'
import api from './api'

// Replace with your Stripe publishable key
const stripePromise = loadStripe('pk_test_yourStripePublishableKey')

export const processPayment = async (paymentMethodId, amount) => {
  try {
    // Create a PaymentIntent on your backend
    const { clientSecret } = await api.payment.createPaymentIntent(amount)
    
    // Confirm the payment on the client
    const stripe = await stripePromise
    const result = await stripe.confirmCardPayment(clientSecret, {
      payment_method: paymentMethodId
    })
    
    if (result.error) {
      // Show error to your customer
      throw new Error(result.error.message)
    } else if (result.paymentIntent.status === 'succeeded') {
      // Payment succeeded
      return {
        success: true,
        paymentIntent: result.paymentIntent,
      }
    }
  } catch (error) {
    throw error
  }
}

export const createPaymentMethod = async (cardElement, billingDetails) => {
  try {
    const stripe = await stripePromise
    const { error, paymentMethod } = await stripe.createPaymentMethod({
      type: 'card',
      card: cardElement,
      billing_details: billingDetails,
    })
    
    if (error) {
      throw new Error(error.message)
    }
    
    return paymentMethod
  } catch (error) {
    throw error
  }
}