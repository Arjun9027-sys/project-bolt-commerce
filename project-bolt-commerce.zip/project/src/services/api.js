import axios from 'axios'

// Create an axios instance
const apiClient = axios.create({
  baseURL: 'https://api.example.com', // Replace with your actual API URL
  timeout: 10000,
  headers: {
    'Content-Type': 'application/json',
  },
})

// Request interceptor for adding auth token
apiClient.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('authToken')
    if (token) {
      config.headers.Authorization = `Bearer ${token}`
    }
    return config
  },
  (error) => Promise.reject(error)
)

// Sample response for development (to be replaced with actual API)
const mockProducts = [
  {
    id: 1,
    name: 'iPhone 15 Pro Max',
    price: 1199.99,
    image: 'https://images.pexels.com/photos/5750001/pexels-photo-5750001.jpeg',
    description: 'The latest iPhone with a powerful A17 Pro chip, stunning Super Retina XDR display, and amazing camera system.',
    category: 'Smartphones',
    rating: 4.9,
    countInStock: 15,
    reviews: [
      { id: 1, username: 'TechFan', rating: 5, comment: 'Best phone I have ever used!', date: '2023-10-15' },
      { id: 2, username: 'JaneSmith', rating: 4.5, comment: 'Great camera and battery life', date: '2023-10-10' },
    ]
  },
  {
    id: 2,
    name: 'MacBook Pro 16"',
    price: 2499.99,
    image: 'https://images.pexels.com/photos/303383/pexels-photo-303383.jpeg',
    description: 'Incredibly powerful. The M3 Pro chip takes pro performance to the next level.',
    category: 'Laptops',
    rating: 4.8,
    countInStock: 10,
    reviews: [
      { id: 1, username: 'ProDesigner', rating: 5, comment: 'Perfect for design work and video editing', date: '2023-09-20' },
    ]
  },
  {
    id: 3,
    name: 'iPad Air',
    price: 599.99,
    image: 'https://images.pexels.com/photos/1334597/pexels-photo-1334597.jpeg',
    description: 'Incredibly capable. Incredibly thin and light. The ultimate iPad experience.',
    category: 'Tablets',
    rating: 4.7,
    countInStock: 25,
    reviews: []
  },
  {
    id: 4,
    name: 'AirPods Pro',
    price: 249.99,
    image: 'https://images.pexels.com/photos/3780681/pexels-photo-3780681.jpeg',
    description: 'Active Noise Cancellation for immersive sound. Transparency mode for hearing what is happening around you.',
    category: 'Audio',
    rating: 4.8,
    countInStock: 30,
    reviews: []
  },
  {
    id: 5,
    name: 'Apple Watch Series 9',
    price: 399.99,
    image: 'https://images.pexels.com/photos/437037/pexels-photo-437037.jpeg',
    description: 'The most advanced Apple Watch yet, with new features to help you stay connected, active, healthy, and safe.',
    category: 'Wearables',
    rating: 4.6,
    countInStock: 20,
    reviews: []
  },
  {
    id: 6,
    name: 'HomePod mini',
    price: 99.99,
    image: 'https://images.pexels.com/photos/7052018/pexels-photo-7052018.jpeg',
    description: 'Room-filling sound. An intelligent assistant. Control your smart home. All with privacy and security built in.',
    category: 'Smart Home',
    rating: 4.5,
    countInStock: 35,
    reviews: []
  },
]

const mockCategories = [
  'Smartphones',
  'Laptops',
  'Tablets',
  'Audio',
  'Wearables',
  'Smart Home',
  'Accessories',
]

// API service object
const api = {
  // Product API
  products: {
    getAll: async (params = {}) => {
      // For development, return mock data
      // In production, uncomment the API call
      // const response = await apiClient.get('/products', { params })
      // return response.data
      
      // Mock implementation
      return {
        products: mockProducts,
        totalPages: 1,
        currentPage: 1,
        total: mockProducts.length,
      }
    },
    
    getById: async (id) => {
      // For development, return mock data
      // In production, uncomment the API call
      // const response = await apiClient.get(`/products/${id}`)
      // return response.data
      
      // Mock implementation
      const product = mockProducts.find(p => p.id === parseInt(id))
      return product || null
    },
    
    getCategories: async () => {
      // For development, return mock data
      // In production, uncomment the API call
      // const response = await apiClient.get('/categories')
      // return response.data
      
      // Mock implementation
      return mockCategories
    },
    
    search: async (query) => {
      // For development, return mock data
      // In production, uncomment the API call
      // const response = await apiClient.get('/products/search', { params: { q: query } })
      // return response.data
      
      // Mock implementation
      return {
        products: mockProducts.filter(
          p => p.name.toLowerCase().includes(query.toLowerCase()) ||
               p.description.toLowerCase().includes(query.toLowerCase())
        ),
        total: mockProducts.length,
      }
    },
  },
  
  // Auth API
  auth: {
    login: async (credentials) => {
      // For development, return mock data
      // In production, uncomment the API call
      // const response = await apiClient.post('/auth/login', credentials)
      // return response.data
      
      // Mock implementation
      return {
        user: {
          id: 1,
          name: 'John Doe',
          email: credentials.email,
          avatar: 'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg',
        },
        token: 'mock-jwt-token',
      }
    },
    
    register: async (userData) => {
      // For development, return mock data
      // In production, uncomment the API call
      // const response = await apiClient.post('/auth/register', userData)
      // return response.data
      
      // Mock implementation
      return {
        user: {
          id: 1,
          name: userData.name,
          email: userData.email,
          avatar: 'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg',
        },
        token: 'mock-jwt-token',
      }
    },
    
    logout: async () => {
      // For development, do nothing
      // In production, uncomment the API call
      // return await apiClient.post('/auth/logout')
      
      // Mock implementation
      return { success: true }
    },
    
    getProfile: async () => {
      // For development, return mock data
      // In production, uncomment the API call
      // const response = await apiClient.get('/auth/profile')
      // return response.data
      
      // Mock implementation
      return {
        user: {
          id: 1,
          name: 'John Doe',
          email: 'john.doe@example.com',
          avatar: 'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg',
          address: {
            street: '123 Main St',
            city: 'San Francisco',
            state: 'CA',
            zipCode: '94105',
            country: 'USA',
          },
          phone: '+1 (123) 456-7890',
        }
      }
    },
  },
  
  // Cart API
  cart: {
    getCart: async () => {
      // For development, return mock data
      // In production, uncomment the API call
      // const response = await apiClient.get('/cart')
      // return response.data
      
      // Mock implementation
      return {
        items: [],
        totalQuantity: 0,
        totalAmount: 0,
      }
    },
    
    addToCart: async (productData) => {
      // For development, return mock data
      // In production, uncomment the API call
      // const response = await apiClient.post('/cart', productData)
      // return response.data
      
      // Mock implementation
      return {
        success: true,
        message: 'Item added to cart',
      }
    },
    
    updateQuantity: async (id, quantity) => {
      // For development, return mock data
      // In production, uncomment the API call
      // const response = await apiClient.put(`/cart/${id}`, { quantity })
      // return response.data
      
      // Mock implementation
      return {
        success: true,
        message: 'Cart updated',
      }
    },
    
    removeFromCart: async (id) => {
      // For development, return mock data
      // In production, uncomment the API call
      // const response = await apiClient.delete(`/cart/${id}`)
      // return response.data
      
      // Mock implementation
      return {
        success: true,
        message: 'Item removed from cart',
      }
    },
  },
  
  // Order API
  orders: {
    placeOrder: async (orderData) => {
      // For development, return mock data
      // In production, uncomment the API call
      // const response = await apiClient.post('/orders', orderData)
      // return response.data
      
      // Mock implementation
      return {
        orderId: 'ORD' + Date.now(),
        success: true,
        message: 'Order placed successfully',
      }
    },
    
    getOrders: async () => {
      // For development, return mock data
      // In production, uncomment the API call
      // const response = await apiClient.get('/orders')
      // return response.data
      
      // Mock implementation
      return [
        {
          id: 'ORD123456',
          date: '2023-10-15',
          total: 2499.99,
          status: 'Delivered',
          items: [
            {
              id: 2,
              name: 'MacBook Pro 16"',
              price: 2499.99,
              quantity: 1,
              image: 'https://images.pexels.com/photos/303383/pexels-photo-303383.jpeg',
            },
          ],
        },
        {
          id: 'ORD123457',
          date: '2023-10-10',
          total: 1449.98,
          status: 'Processing',
          items: [
            {
              id: 1,
              name: 'iPhone 15 Pro Max',
              price: 1199.99,
              quantity: 1,
              image: 'https://images.pexels.com/photos/5750001/pexels-photo-5750001.jpeg',
            },
            {
              id: 4,
              name: 'AirPods Pro',
              price: 249.99,
              quantity: 1,
              image: 'https://images.pexels.com/photos/3780681/pexels-photo-3780681.jpeg',
            },
          ],
        },
      ]
    },
    
    getOrderById: async (id) => {
      // For development, return mock data
      // In production, uncomment the API call
      // const response = await apiClient.get(`/orders/${id}`)
      // return response.data
      
      // Mock implementation
      const orders = [
        {
          id: 'ORD123456',
          date: '2023-10-15',
          total: 2499.99,
          status: 'Delivered',
          tracking: {
            number: 'TRK9876543210',
            carrier: 'UPS',
            estimated_delivery: '2023-10-18',
            status: 'Delivered',
            history: [
              { date: '2023-10-15', status: 'Order placed', location: 'Online' },
              { date: '2023-10-16', status: 'Shipped', location: 'Warehouse' },
              { date: '2023-10-18', status: 'Delivered', location: 'Customer Address' },
            ],
          },
          shipping_address: {
            name: 'John Doe',
            street: '123 Main St',
            city: 'San Francisco',
            state: 'CA',
            zipCode: '94105',
            country: 'USA',
          },
          payment_method: {
            type: 'Credit Card',
            last_four: '4242',
          },
          items: [
            {
              id: 2,
              name: 'MacBook Pro 16"',
              price: 2499.99,
              quantity: 1,
              image: 'https://images.pexels.com/photos/303383/pexels-photo-303383.jpeg',
            },
          ],
        },
        {
          id: 'ORD123457',
          date: '2023-10-10',
          total: 1449.98,
          status: 'Processing',
          tracking: {
            number: 'TRK1234567890',
            carrier: 'FedEx',
            estimated_delivery: '2023-10-20',
            status: 'In Transit',
            history: [
              { date: '2023-10-10', status: 'Order placed', location: 'Online' },
              { date: '2023-10-12', status: 'Shipped', location: 'Warehouse' },
            ],
          },
          shipping_address: {
            name: 'John Doe',
            street: '123 Main St',
            city: 'San Francisco',
            state: 'CA',
            zipCode: '94105',
            country: 'USA',
          },
          payment_method: {
            type: 'PayPal',
            email: 'john.doe@example.com',
          },
          items: [
            {
              id: 1,
              name: 'iPhone 15 Pro Max',
              price: 1199.99,
              quantity: 1,
              image: 'https://images.pexels.com/photos/5750001/pexels-photo-5750001.jpeg',
            },
            {
              id: 4,
              name: 'AirPods Pro',
              price: 249.99,
              quantity: 1,
              image: 'https://images.pexels.com/photos/3780681/pexels-photo-3780681.jpeg',
            },
          ],
        },
      ]
      
      return orders.find(o => o.id === id) || null
    },
  },
  
  // Payment API
  payment: {
    createPaymentIntent: async (amount) => {
      // For development, return mock data
      // In production, uncomment the API call
      // const response = await apiClient.post('/payment/create-payment-intent', { amount })
      // return response.data
      
      // Mock implementation
      return {
        clientSecret: 'mock_client_secret_' + Date.now(),
      }
    },
  },
}

export default api