export default {
  content: [
    "./index.html",
    "./src/**/*.{js,jsx}"
  ],
  theme: {
    extend: {
      colors: {
        primary: {
          50: '#E6F0FA',
          100: '#CCE0F5',
          200: '#99C2EB',
          300: '#66A3E0',
          400: '#3385D6',
          500: '#0066CC',
          600: '#0052A3',
          700: '#003D7A',
          800: '#002952',
          900: '#001429',
        },
        secondary: {
          50: '#E9F7FC',
          100: '#D3EFF9',
          200: '#A7DFF3',
          300: '#7CCFED',
          400: '#50BFE7',
          500: '#2D9CDB',
          600: '#1A7CAF',
          700: '#135D83',
          800: '#0D3E58',
          900: '#061F2C',
        },
        accent: {
          50: '#FEF6EF',
          100: '#FDEDDF',
          200: '#FBDBBF',
          300: '#F9C99F',
          400: '#F7B77F',
          500: '#F2994A',
          600: '#C27A3B',
          700: '#915C2C',
          800: '#613D1E',
          900: '#301F0F',
        },
        success: {
          500: '#27AE60',
        },
        warning: {
          500: '#F2C94C',
        },
        error: {
          500: '#EB5757',
        },
        neutral: {
          50: '#F8F9FA',
          100: '#F1F3F5',
          200: '#E9ECEF',
          300: '#DEE2E6',
          400: '#CED4DA',
          500: '#ADB5BD',
          600: '#868E96',
          700: '#495057',
          800: '#343A40',
          900: '#212529',
        }
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', 'sans-serif'],
      },
      spacing: {
        '1': '8px',
        '2': '16px',
        '3': '24px',
        '4': '32px',
        '5': '40px',
        '6': '48px',
      },
      animation: {
        'fade-in': 'fadeIn 0.3s ease-in-out',
        'slide-up': 'slideUp 0.4s ease-out',
        'pulse-slow': 'pulse 3s cubic-bezier(0.4, 0, 0.6, 1) infinite',
      },
      keyframes: {
        fadeIn: {
          '0%': { opacity: '0' },
          '100%': { opacity: '1' },
        },
        slideUp: {
          '0%': { transform: 'translateY(10px)', opacity: '0' },
          '100%': { transform: 'translateY(0)', opacity: '1' },
        },
      },
    },
  },
  plugins: [],
}